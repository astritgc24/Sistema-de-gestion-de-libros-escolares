<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

// Obtener datos del formulario
$isbn = $_POST['ISBN'];
$titulo = $_POST['Titulo'];
$subtitulo = $_POST['Subtitulo'];
$serie = $_POST['Serie'];
$editorial = $_POST['Editorial'];
$genero = $_POST['Genero'];
$autores = $_POST['Autores'];

// Actualizar datos del libro
$sql_update_libro = "UPDATE libro 
                     SET Titulo='$titulo', Subtitulo='$subtitulo', Serie='$serie', Editorial='$editorial', Genero='$genero'
                     WHERE ISBN='$isbn'";

if (mysqli_query($conexion, $sql_update_libro)) {
    echo "Datos del libro actualizados correctamente.<br>";

    // Eliminar autores actuales del libro
    $sql_delete_autores = "DELETE FROM `libro-autor` WHERE ISBN='$isbn'";
    if (mysqli_query($conexion, $sql_delete_autores)) {
        echo "Autores actuales eliminados correctamente.<br>";
    } else {
        echo "Error al eliminar los autores actuales: " . mysqli_error($conexion) . "<br>";
    }

    // Insertar nuevos autores
    $autores_array = explode(',', $autores);
    foreach ($autores_array as $autor_nombre) {
        $autor_nombre = trim($autor_nombre);
        if (!empty($autor_nombre)) {
            // Verificar si el autor existe, si no, insertarlo
            $sql_check_autor = "SELECT clv_autor FROM autor WHERE nombre_autor='$autor_nombre'";
            $result_check_autor = mysqli_query($conexion, $sql_check_autor);

            if (mysqli_num_rows($result_check_autor) > 0) {
                $autor = mysqli_fetch_assoc($result_check_autor);
                $clv_autor = $autor['clv_autor'];
                echo "Autor existente encontrado: $autor_nombre (clv_autor: $clv_autor).<br>";
            } else {
                $sql_insert_autor = "INSERT INTO autor (nombre_autor) VALUES ('$autor_nombre')";
                if (mysqli_query($conexion, $sql_insert_autor)) {
                    $clv_autor = mysqli_insert_id($conexion);
                    echo "Autor nuevo insertado: $autor_nombre (clv_autor: $clv_autor).<br>";
                } else {
                    echo "Error al insertar el autor: $autor_nombre - " . mysqli_error($conexion) . "<br>";
                    continue;
                }
            }

            // Insertar en libro-autor
            $sql_insert_libro_autor = "INSERT INTO `libro-autor` (ISBN, clv_autor) VALUES ('$isbn', '$clv_autor')";
            if (mysqli_query($conexion, $sql_insert_libro_autor)) {
                echo "Relación libro-autor insertada correctamente para: $autor_nombre.<br>";
            } else {
                echo "Error al insertar la relación libro-autor para: $autor_nombre - " . mysqli_error($conexion) . "<br>";
            }
        }
    }

    // Redirigir a la página principal con un mensaje de éxito
    header("Location: mostrarIngles.php?mensaje=Libro actualizado exitosamente");
} else {
    // Mostrar mensaje de error si falla la actualización del libro
    echo "Error al actualizar el libro: " . mysqli_error($conexion) . "<br>";
}

// Cerrar conexión
mysqli_close($conexion);
?>