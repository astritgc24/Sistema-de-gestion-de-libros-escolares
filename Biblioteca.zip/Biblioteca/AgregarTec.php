<?php
// Verificar si se han recibido los datos del formulario
if (isset($_POST['isbn'], $_POST['titulo'], $_POST['subtitulo'], $_POST['ejemplares'], $_POST['editorial'], $_POST['genero'], $_POST['serie'], $_POST['autores'])) {
    // Obtener los datos del formulario
    $isbn = $_POST['isbn'];
    $titulo = $_POST['titulo'];
    $subtitulo = $_POST['subtitulo'];
    $ejemplares = $_POST['ejemplares'];
    $editorial = $_POST['editorial'];
    $genero = $_POST['genero'];
    $serie = $_POST['serie'];
    $autores = $_POST['autores']; // Se espera una cadena de autores separados por comas

    // Conectar a la base de datos
    $servername = "localhost"; // Cambia esto si tu servidor es diferente
    $username = "root"; // Cambia por tu usuario de base de datos
    $password = ""; // Cambia por tu contraseña de base de datos
    $dbname = "biblioteca_escolar"; // Cambia por el nombre de tu base de datos
    $conexion = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conexion->connect_error) {
        die("Conexión fallida: " . $conexion->connect_error);
    }

    // Escapar las variables para evitar inyección de SQL (opcional, pero recomendado)
    $isbn = $conexion->real_escape_string($isbn);
    $titulo = $conexion->real_escape_string($titulo);
    $subtitulo = $conexion->real_escape_string($subtitulo);
    $autores = $conexion->real_escape_string($autores);

    // Iniciar una transacción
    $conexion->begin_transaction();

    try {
        // Obtener el ID de la disciplina 'Español'
        $query = "SELECT Clv_disciplina FROM disciplina WHERE Descripcion = 'Tecnologia'";
        $result = $conexion->query($query);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $disciplina_id = $row['Clv_disciplina'];
        } else {
            throw new Exception("Disciplina 'Tecnologia' no encontrada.");
        }

        // Insertar el nuevo libro en la tabla libro
        $query = "INSERT INTO libro (ISBN, Titulo, Subtitulo, Serie, Disciplina, Editorial, Genero)
                  VALUES ('$isbn', '$titulo', '$subtitulo', $serie, $disciplina_id, $editorial, $genero)";
        if (!$conexion->query($query)) {
            throw new Exception("Error al insertar el libro: " . $conexion->error);
        }

        // Restablecer el AUTO_INCREMENT de la tabla ejemplar para este conjunto de inserciones
        $query = "SELECT COALESCE(MAX(Folio), 0) + 1 AS nextFolio FROM ejemplar";
        $result = $conexion->query($query);
        $row = $result->fetch_assoc();
        $nextFolio = $row['nextFolio'];

        // Insertar el número especificado de ejemplares con estado 'Disponible'
        for ($i = 0; $i < $ejemplares; $i++) {
            $query = "INSERT INTO ejemplar (Folio, ISBN, Estado) VALUES ($nextFolio + $i, '$isbn', 'Disponible')";
            if (!$conexion->query($query)) {
                throw new Exception("Error al insertar los ejemplares: " . $conexion->error);
            }
        }

        // Insertar los autores del libro en la tabla autor si no existen y obtener sus IDs
        $autoresArray = explode(',', $autores);
        foreach ($autoresArray as $autor_nombre) {
            $autor_nombre = trim($autor_nombre);

            // Buscar si el autor ya existe
            $query = "SELECT clv_autor FROM autor WHERE nombre_autor = '$autor_nombre'";
            $result = $conexion->query($query);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $autor_id = $row['clv_autor'];
            } else {
                // Si no existe, insertar el nuevo autor
                $query = "INSERT INTO autor (nombre_autor) VALUES ('$autor_nombre')";
                if (!$conexion->query($query)) {
                    throw new Exception("Error al insertar el autor: " . $conexion->error);
                }
                $autor_id = $conexion->insert_id;
            }

            // Insertar relación libro-autor
            $query = "INSERT INTO `libro-autor` (ISBN, clv_autor) VALUES ('$isbn', $autor_id)";
            if (!$conexion->query($query)) {
                throw new Exception("Error al insertar la relación libro-autor: " . $conexion->error);
            }
        }

        // Confirmar la transacción
        $conexion->commit();
        echo json_encode(array("success" => true, "message" => "Libro registrado con éxito."));
    } catch (Exception $e) {
        // Revertir la transacción
        $conexion->rollback();
        echo json_encode(array("success" => false, "message" => $e->getMessage()));
    }

    // Cerrar la conexión
    $conexion->close();
} else {
    // No se recibieron todos los datos del formulario
    
}
?>
