<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Nuevo Libro</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/estilo1-1.css">
    <style>
        .message {
            display: none;
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        body {
            background-color:  #87f4c3;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container-fluid {
            background-image: url('imagenes/fondoModificado.png');
            background-size: cover;
            background-position: center;
        }

        .header-container {
            background-color: #ffffff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .nav-links,
        .nav-icons {
            display: flex;
            align-items: center;
        }

        .nav-links a,
        .nav-icons a {
            display: flex;
            align-items: center;
            text-align: center;
            color: #333;
            margin: 10px;
            text-decoration: none;
        }

        .nav-links img,
        .nav-icons img {
            width: 30px;
            height: auto;
            margin-right: 10px;
        }

        .table-icons a {
            color: #dc3545;
        }

        .custom-table {
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .custom-table th,
        .custom-table td {
            background-color: white;
            border: 1px solid #dee2e6;
            color: #333;
        }

        .custom-table th {
            background-color: #f8f9fa;
        }

        .custom-table td {
            vertical-align: middle;
        }

        .footer-container {
            background-color: #ffffff;
            padding: 20px;
            border-top: 1px solid #ddd;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .footer-links a {
            color: #333;
            margin-right: 10px;
        }

        @media (max-width: 576px) {
            .nav-links {
                flex-direction: column;
                align-items: center;
            }
        }

        .btn-yellow {
            background-color:  #87f4c3;
            color: #333;
            border-color: #87f4c3;
            border-radius: 50px;
            margin-right: 10px;
        }

        .btn-yellow:hover {
            background-color: #87f4c3;
        }

        .btn-return {
            background-color: #ffffff;
            border-radius: 50px;
            padding: 5px 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-return img {
            width: 30px;
            height: auto;
        }


        .form-group.row.align-items-center {
            display: flex;
            align-items: center;
        }

        .form-group .col-form-label {
            margin-bottom: 0;
            white-space: nowrap;
        }

        .form-group .form-control {
            flex-grow: 1;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="half-screen left-half"></div>
        <div class="half-screen right-half">
            <div class="row header-container align-items-center">
                <div class="col-auto nav-links">
                    <img id="selected-card-img" src="images/cien.png" alt="Pintura" class="img-fluid" style="width: 70px; height: auto;">
                </div>
                <div class="col-auto">
                    <h5 class="text-uppercase">Artes</h5>
                </div>
                <div class="col nav-links justify-content-center">
                    <a href="RegistrarArtes.php">
                        <img src="imagenes/registrar.png" alt="Registrar" class="img-fluid" style="width: 70px; height: auto;">
                        <h1>REGISTRAR</h1>
                    </a>
                </div>
                <div class="col-auto ml-auto nav-icons">
                    <a href="index.html" class="btn-exit-system">
                        <img src="images/log.png" alt="Cerrar sesión" style="width: 130px; height: auto;">
                    </a>
                </div>
            </div>
            <div class="row justify-content-center mt-5">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <div id="mensaje" class="message"></div>
                            <form id="add-book-form" action="agregar_libro.php" method="post" onsubmit="return validateForm(event)">
                                <div class="form-group row align-items-center">
                                    <label for="isbn" class="col-sm-2 col-form-label">ISBN</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="isbn" name="isbn" required pattern="\d+" title="Solo números">
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="titulo" class="col-sm-2 col-form-label">Título del Libro</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="titulo" name="titulo" required pattern="[A-Za-z0-9\s]+" title="Solo letras y números">
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="subtitulo" class="col-sm-2 col-form-label">Subtítulo</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="subtitulo" name="subtitulo" pattern="[A-Za-z0-9\s]*" title="Solo letras y números">
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="ejemplares" class="col-sm-2 col-form-label">Ejemplares</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" id="ejemplares" name="ejemplares" value="1" required min="1" readonly onfocus="this.removeAttribute('readonly');" onblur="this.setAttribute('readonly', true);">
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="editorial" class="col-sm-2 col-form-label">Editorial</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="editorial" name="editorial" required>
                                            <?php
                                            include("conexion/conectar-mysql.php");
                                            $sql = "SELECT Clv_editorial, Nombre_editorial FROM editorial";
                                            $result = $conexion->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $nombreEditorial = $row["Nombre_editorial"];
                                                    echo "<option value='" . $row["Clv_editorial"] . "'>$nombreEditorial</option>";
                                                }
                                            } else {
                                                echo "<option value=''>No hay editoriales disponibles</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="genero" class="col-sm-2 col-form-label">Género</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="genero" name="genero" required>
                                            <?php
                                            $sql = "SELECT Clv_genero, Nombre_genero FROM genero";
                                            $result = $conexion->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $nombreGenero = $row["Nombre_genero"];
                                                    echo "<option value='" . $row["Clv_genero"] . "'>$nombreGenero</option>";
                                                }
                                            } else {
                                                echo "<option value=''>No hay géneros disponibles</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="serie" class="col-sm-2 col-form-label">Serie</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="serie" name="serie" required>
                                            <?php
                                            $sql = "SELECT Clv_serie, Nombre_serie FROM serie";
                                            $result = $conexion->query($sql);
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    $nombreSerie = $row["Nombre_serie"];
                                                    echo "<option value='" . $row["Clv_serie"] . "'>$nombreSerie</option>";
                                                }
                                            } else {
                                                echo "<option value=''>No hay series disponibles</option>";
                                            }
                                            $conexion->close();
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row align-items-center">
                                    <label for="autores" class="col-sm-2 col-form-label">Autores</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="autores" name="autores" required pattern="[A-Za-z\s,]+" title="Solo letras separadas por comas">
                                    </div>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <button type="button" class="btn btn-return" onclick="window.location.href='listaLibrosCiencias.php'">
                                        <img src="imagenes/regresar.png" alt="Regresar">
                                    </button>
                                    <button type="submit" class="btn btn-yellow">Agregar Libro</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function validateForm(event) {
            event.preventDefault();

            var isbn = document.getElementById('isbn').value;
            var titulo = document.getElementById('titulo').value;
            var subtitulo = document.getElementById('subtitulo').value;
            var autores = document.getElementById('autores').value;

            var isbnPattern = /^\d+$/;
            var textPattern = /^[A-Za-z0-9\s]+$/;
            var autoresPattern = /^[A-Za-z\s,]+$/;

            if (!isbnPattern.test(isbn)) {
                showMessage('ISBN debe contener solo números.', 'error');
                return false;
            }

            if (!textPattern.test(titulo)) {
                showMessage('Título debe contener solo letras y números.', 'error');
                return false;
            }

            if (subtitulo !== "" && !textPattern.test(subtitulo)) {
                showMessage('Subtítulo debe contener solo letras y números.', 'error');
                return false;
            }

            if (!autoresPattern.test(autores)) {
                showMessage('Autores debe contener solo letras y comas.', 'error');
                return false;
            }

            $.ajax({
                url: 'agregar_libroCiencias.php',
                type: 'POST',
                data: $('#add-book-form').serialize(),
                success: function(response) {
                    var data = JSON.parse(response);
                    if (data.success) {
                        showMessage(data.message, 'success');
                        setTimeout(function() {
                            window.location.href = 'listaLibrosCiencias.php';
                        }, 2000);
                    } else {
                        showMessage(data.message, 'error');
                    }
                },
                error: function() {
                    showMessage('Error al procesar la solicitud.', 'error');
                }
            });

            return true;
        }

        function showMessage(message, type) {
            var mensajeDiv = document.getElementById('mensaje');
            mensajeDiv.className = 'message ' + type;
            mensajeDiv.innerText = message;
            mensajeDiv.style.display = 'block';
        }

        document.getElementById('ejemplares').addEventListener('keydown', function(e) {
            if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown' && e.key !== 'Tab' && e.key !== 'Backspace') {
                e.preventDefault();
            }
        });
    </script>
</body>

</html>
