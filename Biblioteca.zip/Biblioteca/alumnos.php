<?php
// Incluir archivo de conexión a la base de datos
include("conexion/conectar-mysql.php");

// Inicializar variables para el mensaje y el estilo del alert
$mensaje = "";
$alertClass = "";

// Variables para mensajes de error específicos
$errores = array(
    'matricula' => '',
    'nombre' => '',
    'apellido1' => '',
    'apellido2' => '',
    'grado' => '',
    'grupo' => ''
);

// Verificar si se recibieron datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener datos del formulario y escaparlos para evitar inyección SQL
    $matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $apellido1 = mysqli_real_escape_string($conexion, $_POST['apellido1']);
    $apellido2 = mysqli_real_escape_string($conexion, $_POST['apellido2']);
    $grado = mysqli_real_escape_string($conexion, $_POST['grado']);
    $grupo = mysqli_real_escape_string($conexion, $_POST['grupo']);

    // Validar los campos
    if (!preg_match("/^\d+$/", $matricula)) {
        $errores['matricula'] = "La matrícula solo debe contener números.";
    }
    if (!preg_match("/^[a-zA-Z\s]+$/", $nombre)) {
        $errores['nombre'] = "El nombre solo debe contener letras.";
    }
    if (!preg_match("/^[a-zA-Z\s]+$/", $apellido1)) {
        $errores['apellido1'] = "El apellido paterno solo debe contener letras.";
    }
    if (!preg_match("/^[a-zA-Z\s]+$/", $apellido2)) {
        $errores['apellido2'] = "El apellido materno solo debe contener letras.";
    }
    if (!preg_match("/^\d{1}$/", $grado)) {
        $errores['grado'] = "El grado solo debe contener un número.";
    }
    if (!preg_match("/^[a-zA-Z]{1}$/", $grupo)) {
        $errores['grupo'] = "El grupo solo debe contener una letra.";
    }

    // Si no hay errores, proceder con el registro
    if (empty(array_filter($errores))) {
        // Llamar al procedimiento almacenado para registrar alumno
        $query = "CALL RegistrarAlumno('$matricula', '$nombre', '$apellido1', '$apellido2', '$grado', '$grupo')";

        $resultado = mysqli_query($conexion, $query);

        if ($resultado) {
            $mensaje = "Alumno registrado correctamente.";
            $alertClass = "alert-success"; // Clase de Bootstrap para mensaje de éxito
        } else {
            $mensaje = "Error al registrar el alumno: " . mysqli_error($conexion);
            $alertClass = "alert-danger"; // Clase de Bootstrap para mensaje de error
        }
    }
}

// Cerrar la conexión
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Alumno</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #ffffff;
            color: #000000;
            font-family: 'Arial', sans-serif;
        }
        h1 {
            color: #000000;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-control {
            border: 1px solid #000000;
            border-radius: 5px;
            color: #000000;
            background-color: #ffffff;
        }
        .btn-primary {
            background-color: #ffffff;
            border-color: #000000;
            color: #000000;
            width: 100%;
        }
        .btn-primary:hover {
            background-color: #f3f3f3;
        }
        .alert {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
        }
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
        .alert-danger {
            background-color: #f8d7da;
            border-color: #f5c6cb;
            color: #721c24;
        }
        .fa {
            margin-right: 10px;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar Alumno <i class="fas fa-user-plus"></i></h1>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label for="matricula"><i class="fas fa-id-card"></i> Matrícula del Alumno</label>
                <input type="text" class="form-control" id="matricula" name="matricula" required>
                <div class="error"><?php echo $errores['matricula']; ?></div>
            </div>
            <div class="form-group">
                <label for="nombre"><i class="fas fa-user"></i> Nombre del Alumno</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
                <div class="error"><?php echo $errores['nombre']; ?></div>
            </div>
            <div class="form-group">
                <label for="apellido1"><i class="fas fa-user"></i> Apellido paterno del Alumno</label>
                <input type="text" class="form-control" id="apellido1" name="apellido1" required>
                <div class="error"><?php echo $errores['apellido1']; ?></div>
            </div>
            <div class="form-group">
                <label for="apellido2"><i class="fas fa-user"></i> Apellido materno del Alumno</label>
                <input type="text" class="form-control" id="apellido2" name="apellido2" required>
                <div class="error"><?php echo $errores['apellido2']; ?></div>
            </div>
            <div class="form-group">
                <label for="grado"><i class="fas fa-graduation-cap"></i> Grado</label>
                <input type="text" class="form-control" id="grado" name="grado" required>
                <div class="error"><?php echo $errores['grado']; ?></div>
            </div>
            <div class="form-group">
                <label for="grupo"><i class="fas fa-users"></i> Grupo</label>
                <input type="text" class="form-control" id="grupo" name="grupo" required>
                <div class="error"><?php echo $errores['grupo']; ?></div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Registrar Alumno</button>
        </form>

        <a href="mostrarAlumnos.php" class="btn btn-link text-dark"><i class="fas fa-home"></i> Regresar</a>

        <?php if (!empty($mensaje)): ?>
            <div class="alert <?php echo $alertClass; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>

