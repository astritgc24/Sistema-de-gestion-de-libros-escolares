<?php
include("conexion/conectar-mysql.php");

if (isset($_GET['folio'])) {
    $folio = $_GET['folio'];

    try {
        // Verificar si el ejemplar está asociado a préstamos
        $sql = "SELECT COUNT(*) AS total FROM prestamo WHERE Folio_ejemplar = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "s", $folio);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $total_prestamos);
        mysqli_stmt_fetch($stmt);

        // Preparar la respuesta
        $response = array(
            'prestamo' => ($total_prestamos > 0) ? 'true' : 'false'
        );

        mysqli_stmt_close($stmt);
    } catch (mysqli_sql_exception $e) {
        // En caso de error, devolver un estado de error
        $response = array(
            'prestamo' => 'error'
        );
    }

    echo json_encode($response);
} else {
    // Si no se recibió el parámetro folio, retornar un estado de error
    $response = array(
        'prestamo' => 'error'
    );

    echo json_encode($response);
}

// Cerrar conexión
mysqli_close($conexion);
?>
