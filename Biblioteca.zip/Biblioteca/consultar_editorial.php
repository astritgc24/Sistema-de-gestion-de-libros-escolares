<?php
// Incluir el archivo de conexión
include("conexion/conectar-mysql.php");

// Iniciar sesión
session_start();

// Verificar si se recibió el parámetro clv_editorial
if (isset($_GET['clv_editorial'])) {
    $clv_editorial = $_GET['clv_editorial'];

    // Llamar al procedimiento almacenado para eliminar la editorial
    $sql_delete = "CALL EliminarEditorial($clv_editorial)";

    if (mysqli_query($conexion, $sql_delete)) {
        // Guardar mensaje de éxito en la sesión
        $_SESSION['mensaje_exito'] = "Editorial eliminada correctamente.";
    } else {
        // Guardar mensaje de error en la sesión
        $_SESSION['mensaje_error'] = "Error al eliminar la editorial: " . mysqli_error($conexion);
    }

    // Redirigir a la misma página para mostrar el mensaje
    header("Location: consultar_editorial.php");
    exit();
}

// Preparar la consulta para mostrar las editoriales
$sql = "SELECT Clv_editorial, Nombre_editorial FROM editorial";
$result = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Editoriales</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Lista de Editoriales</h2>

        <?php
        // Mostrar mensaje de éxito si existe
        if (isset($_SESSION['mensaje_exito'])) {
            echo '<div class="alert alert-success d-flex align-items-center" role="alert">
                    <i class="fas fa-check-circle mr-2"></i>' . $_SESSION['mensaje_exito'] . '</div>';
            unset($_SESSION['mensaje_exito']); // Limpiar mensaje de sesión
        }

        // Mostrar mensaje de error si existe
        if (isset($_SESSION['mensaje_error'])) {
            echo '<div class="alert alert-danger d-flex align-items-center" role="alert">
                    <i class="fas fa-exclamation-circle mr-2"></i>' . $_SESSION['mensaje_error'] . '</div>';
            unset($_SESSION['mensaje_error']); // Limpiar mensaje de sesión
        }
        ?>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Editorial</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        // Verificar si hay resultados de la consulta
                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($regEditorial = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $regEditorial['Clv_editorial'] . "</td>";
                                echo "<td>" . $regEditorial['Nombre_editorial'] . "</td>";
                                echo "<td>" . 
                                     "<a href='editar_editoriales.php?clv_editorial=" . $regEditorial['Clv_editorial'] . "' class='btn btn-primary btn-sm'>Editar</a> " . 
                                     "<a href='consultar_editorial.php?clv_editorial=" . $regEditorial['Clv_editorial'] . "' class='btn btn-danger btn-sm'>Eliminar</a>" . 
                                     "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>No hay editoriales registradas.</td></tr>";
                        }

                        // Cerrar la conexión (opcional, si se desea cerrar explícitamente)
                        // mysqli_close($conexion);
                    ?>
                </tbody>
            </table>
        </div>
        <div class="text-right">
            <a href="inicio.html" class="btn btn-secondary">Regresar</a>
            <a href="editorial.php" class="btn btn-success">Agregar una Editorial</a>
            <a href="inicio.html" class="btn btn-info">Volver al Inicio</a>
        </div>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
</body>
</html>
