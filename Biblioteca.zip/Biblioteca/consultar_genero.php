<?php
// Incluir el archivo de conexión
include("conexion/conectar-mysql.php");

// Iniciar sesión
session_start();

// Verificar si se recibió el parámetro clv_genero
if (isset($_GET['clv_genero'])) {
    $clv_genero = $_GET['clv_genero'];

    // Llamar al procedimiento almacenado para eliminar el género
    $sql_delete = "CALL EliminarGenero($clv_genero)";

    if (mysqli_query($conexion, $sql_delete)) {
        // Guardar mensaje de éxito en la sesión
        $_SESSION['mensaje_exito'] = "Género eliminado correctamente.";
    } else {
        // Guardar mensaje de error en la sesión
        $_SESSION['mensaje_error'] = "Error al eliminar el género: " . mysqli_error($conexion);
    }

    // Redirigir a la misma página para mostrar el mensaje
    header("Location: consultar_genero.php");
    exit();
}

// Preparar la consulta para mostrar los géneros
$sql = "CALL MostrarGeneros()";
$result = mysqli_query($conexion, $sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Géneros</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Lista de Géneros</h2>

        <?php
        // Mostrar mensaje de éxito si existe
        if (isset($_SESSION['mensaje_exito'])) {
            echo '<div class="alert alert-success d-flex align-items-center" role="alert">
                    <i class="fas fa-check-circle mr-2"></i>' . $_SESSION['mensaje_exito'] . '</div>';
            unset($_SESSION['mensaje_exito']); // Limpiar mensaje de sesión
        }

        // Mostrar mensaje de error si existe
        if (isset($_SESSION['mensaje_error'])) {
            echo '<div class="alert alert-danger d-flex align-items-center" role="alert">
                    <i class="fas fa-exclamation-circle mr-2"></i>' . $_SESSION['mensaje_error'] . '</div>';
            unset($_SESSION['mensaje_error']); // Limpiar mensaje de sesión
        }
        ?>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Género</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        // Verificar si hay resultados de la consulta
                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($regGenero = mysqli_fetch_array($result)) {
                                echo "<tr>";
                                echo "<th scope='row'>" . $regGenero['Clv_genero'] . "</th>";
                                echo "<td>" . $regGenero['Nombre_genero'] . "</td>";
                                echo "<td>" . 
                                     "<a href='editar_genero.php?clv_genero=" . $regGenero['Clv_genero'] . "' class='btn btn-primary btn-sm'>Editar</a> " . 
                                     "<a href='consultar_genero.php?clv_genero=" . $regGenero['Clv_genero'] . "' class='btn btn-danger btn-sm'>Eliminar</a>" . 
                                     "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>No se encontraron géneros.</td></tr>";
                        }

                        // Cerrar la conexión
                        mysqli_close($conexion);
                    ?>
                </tbody>
            </table>
        </div>
        <div class="text-right">
            <a href="inicio.html" class="btn btn-secondary">Regresar</a>
            <a href="generos.php" class="btn btn-success">Agregar un Género</a>
            <a href="inicio.html" class="btn btn-info">Volver al Inicio</a>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
