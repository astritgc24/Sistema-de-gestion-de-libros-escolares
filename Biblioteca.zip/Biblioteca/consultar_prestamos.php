<?php
session_start(); // Iniciar sesión

// Verificar si la variable de sesión 'nombre' está establecida
if(isset($_SESSION['nombre'])) {
    // Incluir archivo de conexión a la base de datos
    include 'conexion/conectar-mysql.php';

    // Obtener el nombre de usuario de la sesión
    $nombre = $_SESSION['nombre'];

    // Consulta para obtener el rol del usuario basado en el nombre
    $query = "SELECT rol FROM usuarios WHERE nombre = '$nombre'";
    $result = mysqli_query($conexion, $query);

    if ($result) {
        // Verificar si se encontró un registro
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $rol = $row['rol'];

            // Verificar si el rol es 'orientador'
            if ($rol === 'orientador') {
                // Función para obtener los préstamos utilizando el procedimiento almacenado
                function obtenerPrestamos() {
                    global $conexion;

                    // Llamada al procedimiento almacenado
                    $query = "CALL MostrarPrestamoss()";

                    $result = mysqli_query($conexion, $query);

                    if (!$result) {
                        die("Error al ejecutar el procedimiento almacenado: " . mysqli_error($conexion));
                    }

                    return $result;
                }

                // Obtener los préstamos
                $prestamos = obtenerPrestamos();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prestamos</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .icon-btn {
            background: none;
            border: none;
            color: inherit;
            padding: 0;
            cursor: pointer;
        }
        .icon-btn i {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Encabezado -->
      
        <div class="row header-container align-items-center">
            <div class="col-auto nav-links">
                <img id="selected-card-img" src="images/leer.png" alt="Pintura" class="img-fluid" style="width: 60px; height: auto;">
            </div>
            <div class="col-auto">
                <h5 class="text-uppercase">PRESTAMOS</h5>
                
            </div>
            <div class="col nav-links justify-content-center">
            <a href="mostrarAlumnos.php">
    <i class="fas fa-user-graduate" style="font-size: 30px;"></i>
    <span>Consultar Alumnos</span>
</a>

               
               
            </div>
            <div class="col-auto ml-auto nav-icons">
                <a href="index.html" class="btn-exit-system">
                    <img src="images/log.png" alt="Cerrar sesión" style="width: 100px; height: auto;">
                </a>
            </div>
        </div>

        <!-- Contenido principal -->
        <div class="row justify-content-center mt-4">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table">
                        <thead>
                            <tr>
                                <th scope="col">Folio Préstamo</th>
                                <th scope="col">Folio Ejemplar</th>
                                <th scope="col">ISBN</th>
                                <th scope="col">Titulo</th>
                                <th scope="col">Matrícula</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Apellido paterno</th>
                                <th scope="col">Apellido materno</th>
                                <th scope="col">Grado</th>
                                <th scope="col">Grupo</th>
                                <th scope="col">Disciplina</th>
                                <th scope="col">Fecha Préstamo</th>
                                <th scope="col">Fecha Entrega</th>
                                <th scope="col">Acciones</th>
                                <th scope="col">Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Iterar sobre los resultados y mostrar cada préstamo en una fila de la tabla
                            while ($row = mysqli_fetch_assoc($prestamos)) {
                                echo "<tr>";
                                echo "<td>" . $row['Clave'] . "</td>";
                                echo "<td>" . $row['Folio'] . "</td>";
                                echo "<td>" . $row['ISBN'] . "</td>";
                                echo "<td>" . $row['Titulo'] . "</td>";
                                echo "<td>" . $row['Matricula'] . "</td>";
                                echo "<td>" . $row['Nombre'] . "</td>";
                                echo "<td>" . $row['ApellidoPaterno'] . "</td>";
                                echo "<td>" . $row['ApellidoMaterno'] . "</td>";
                                echo "<td>" . $row['Grado'] . "</td>";
                                echo "<td>" . $row['Grupo'] . "</td>";
                                echo "<td>" . $row['Disciplina'] . "</td>";
                                echo "<td>" . $row['Fecha_Prestamo'] . "</td>"; // Fecha de préstamo
                                echo "<td>" . $row['Fecha_Entrega'] . "</td>"; // Fecha de entrega
                                
                                // Acciones
                                echo "<td>";
                                echo "<a href='editar_prestamo.php?folio_prestamo=" . $row['Clave'] . "' class='text-primary mr-2'>";
                                echo "<i class='fas fa-pencil-alt'></i></a>";
                                echo "<a href='registrar_fecha_entregada.php?folio_prestamo=" . $row['Clave'] . "&folio_ejemplar=" . $row['Folio'] . "' class='text-warning mr-2'>";
                                echo "<i class='fas fa-clock'></i></a>";
                                echo "<button class='icon-btn' onclick=\"confirmDelete('" . $row['Titulo'] . "', " . $row['Clave'] . ")\">";
                                echo "<i class='fas fa-trash'></i></button>";
                                echo "</td>";

                                // Estado del préstamo
                                echo "<td>" . $row['Estado'] . "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<!-- Modal para registrar la entrega -->
<div class="modal fade" id="modalRegistrarEntrega" tabindex="-1" aria-labelledby="modalRegistrarEntregaLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalRegistrarEntregaLabel">Registrar Entrega</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="formRegistrarEntrega">
                    <div class="form-group">
                        <label for="fecha_entrega_modal">Fecha de Entrega</label>
                        <input type="date" class="form-control" id="fecha_entrega_modal" required>
                    </div>
                    <input type="hidden" id="folio_prestamo">
                    <input type="hidden" id="folio_ejemplar">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="guardarFechaEntrega()">Guardar</button>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
function confirmDelete(titulo, folioPrestamo) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Vas a eliminar el préstamo del libro: " + titulo,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminarlo'
    }).then((result) => {
        if (result.isConfirmed) {
            // Llamada AJAX para eliminar el préstamo
            $.ajax({
                type: "POST",
                url: "eliminar_prestamo.php",
                data: { folio_prestamo: folioPrestamo },
                success: function(response) {
                    Swal.fire(
                        'Eliminado!',
                        'El préstamo ha sido eliminado.',
                        'success'
                    ).then(function() {
                        location.reload();
                    });
                },
                error: function(xhr, status, error) {
                    Swal.fire(
                        'Error!',
                        'No se pudo eliminar el préstamo. Inténtalo nuevamente.',
                        'error'
                    );
                }
            });
        }
    });
}
</script>
<?php
            } else {
                // Mostrar un mensaje de error para otros roles
                echo "Usted no tiene los suficientes permisos para poder consultar préstamos.";
            }
        } else {
            // Mostrar un mensaje de error si no se encontró el usuario
            echo "Usuario no encontrado.";
        }
    } else {
        // Mostrar un mensaje de error si la consulta falló
        echo "Error al consultar la base de datos.";
    }

    // Cerrar conexión
    mysqli_close($conexion);
} else {
    // La variable de sesión 'nombre' no está establecida, mostrar un mensaje de error
    echo "No cuenta con los permisos suficientes para consultar prestamos.";
}
?>
