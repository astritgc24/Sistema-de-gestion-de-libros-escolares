<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

// Obtener el ISBN del libro a editar desde la URL
$isbn = $_GET['ISBN'];

// Consultar los datos del libro
$sql_libro = "SELECT l.ISBN, l.Titulo, l.Subtitulo, l.Serie, l.Disciplina, l.Editorial, l.Genero, 
               GROUP_CONCAT(a.nombre_autor) AS Autores 
        FROM libro l
        LEFT JOIN `libro-autor` la ON l.ISBN = la.ISBN
        LEFT JOIN autor a ON la.clv_autor = a.clv_autor
        WHERE l.ISBN = '$isbn'
        GROUP BY l.ISBN";

$result_libro = mysqli_query($conexion, $sql_libro);
$libro = mysqli_fetch_assoc($result_libro);

// Consultar las opciones para los combo boxes
$sql_series = "SELECT Clv_serie, Nombre_serie FROM serie";
$result_series = mysqli_query($conexion, $sql_series);

$sql_editoriales = "SELECT Clv_editorial, Nombre_editorial FROM editorial";
$result_editoriales = mysqli_query($conexion, $sql_editoriales);

$sql_generos = "SELECT Clv_genero, Nombre_genero FROM genero";
$result_generos = mysqli_query($conexion, $sql_generos);

// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .message {
      display: none;
      margin-top: 20px;
      padding: 15px;
      border-radius: 5px;
    }
    .message.success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }
    .message.error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }
    body {
      background-color: #a1b8ec;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    .container-fluid {
      background-image: url('imagenes/fondoModificado.png');
      background-size: cover;
      background-position: center;
    }

    .header-container {
      background-color: #ffffff;
      padding: 10px 0;
      border-bottom: 1px solid #ddd;
    }

    .nav-links, .nav-icons {
      display: flex;
      align-items: center;
    }

    .nav-links a, .nav-icons a {
      display: flex;
      align-items: center;
      text-align: center;
      color: #333;
      margin: 10px;
      text-decoration: none;
    }

    .nav-links img, .nav-icons img {
      width: 30px;
      height: auto;
      margin-right: 10px;
    }

    .table-icons a {
      color: #dc3545;
    }

    .custom-table {
      background-color: white;
      border: 1px solid #dee2e6;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .custom-table th, .custom-table td {
      background-color: white;
      border: 1px solid #dee2e6;
      color: #333;
    }

    .custom-table th {
      background-color: #f8f9fa;
    }

    .custom-table td {
      vertical-align: middle;
    }

    .footer-container {
      background-color: #ffffff;
      padding: 20px;
      border-top: 1px solid #ddd;
    }

    .footer-links a {
      color: #333;
      margin-right: 10px;
    }

    @media (max-width: 576px) {
      .nav-links {
        flex-direction: column;
        align-items: center;
      }
    }

    .btn-yellow {
      background-color: #a1b8ec;
      color: #333;
      border-color: #a1b8ec;
      border-radius: 50px;
      margin-right: 10px;
    }

    .btn-yellow:hover {
      background-color: #a1b8ec;
    }

    .btn-return {
      background-color: #ffffff;
      padding: 5px 15px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .btn-return img {
      width: 30px;
      height: auto;
    }

    
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row header-container align-items-center">
            <div class="col-auto nav-links">
                <img id="selected-card-img" src="images/fisica.png" alt="Pintura" class="img-fluid" style="width: 70px; height: auto;">
            </div>
            <div class="col-auto">
                <h5 class="text-uppercase">EDUCACION FISICA</h5>
            </div>
            <div class="col nav-links justify-content-center">
                <a href="Registrar_educacion.php">
                    <img src="imagenes/editar.png" alt="Registrar" class="img-fluid" style="width: 70px; height: auto;">
                    <h1>EDITAR</h1>
                </a>
            </div>
            <div class="col-auto ml-auto nav-icons">
                <a href="index.html" class="btn-exit-system">
                    <img src="images/log.png" alt="Log" style="width: 130px; height: auto;">
                </a>
            </div>
        </div>
        
        <div class="container">
            <div class="card mt-3">
                <div class="card-body">
                    <form action="ActualizarEdu.php" method="POST">
                        <input type="hidden" name="ISBN" value="<?= $libro['ISBN'] ?>">
                        <div class="form-group row align-items-center">
                            <label for="Titulo" class="col-sm-2 col-form-label">Título</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="Titulo" name="Titulo" value="<?= $libro['Titulo'] ?>" required>
                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label for="Subtitulo" class="col-sm-2 col-form-label">Subtítulo</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="Subtitulo" name="Subtitulo" value="<?= $libro['Subtitulo'] ?>">
                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label for="Serie" class="col-sm-2 col-form-label">Serie</label>
                            <div class="col-sm-10">
                                <select class="form-control" id="Serie" name="Serie">
                                    <?php while ($serie = mysqli_fetch_assoc($result_series)) { ?>
                                        <option value="<?= $serie['Clv_serie'] ?>" <?= ($serie['Clv_serie'] == $libro['Serie']) ? 'selected' : '' ?>>
                                            <?= $serie['Nombre_serie'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label for="Editorial" class="col-sm-2 col-form-label">Editorial</label>
                            <div class="col-sm-10">
                                <select class="form-control" id="Editorial" name="Editorial">
                                    <?php while ($editorial = mysqli_fetch_assoc($result_editoriales)) { ?>
                                        <option value="<?= $editorial['Clv_editorial'] ?>" <?= ($editorial['Clv_editorial'] == $libro['Editorial']) ? 'selected' : '' ?>>
                                            <?= $editorial['Nombre_editorial'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label for="Genero" class="col-sm-2 col-form-label">Género</label>
                            <div class="col-sm-10">
                                <select class="form-control" id="Genero" name="Genero">
                                    <?php while ($genero = mysqli_fetch_assoc($result_generos)) { ?>
                                        <option value="<?= $genero['Clv_genero'] ?>" <?= ($genero['Clv_genero'] == $libro['Genero']) ? 'selected' : '' ?>>
                                            <?= $genero['Nombre_genero'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row align-items-center">
                            <label for="Autores" class="col-sm-2 col-form-label">Autores (separados por comas)</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="Autores" name="Autores" value="<?= $libro['Autores'] ?>">
                            </div>
                        </div>
                        <div class="d-flex justify-content-center">
                        <button type="button" class="btn btn-return" onclick="window.location.href='listaLibrosEducacion.php'">
                        <img src="imagenes/regresar.png" alt="Regresar">
                            <button type="submit" class="btn btn-yellow">Actualizar Libro</button>
                            
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>
</body>
</html>

</html>
