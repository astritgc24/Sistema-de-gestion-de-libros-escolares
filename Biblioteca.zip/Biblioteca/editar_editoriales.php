

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Editorial</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Editar Editorial</h2>

        <?php
        // Incluir el archivo de conexión
        include("conexion/conectar-mysql.php");

        // Verificar si se recibió el parámetro clv_editorial
        if (isset($_GET['clv_editorial'])) {
            $clv_editorial = $_GET['clv_editorial'];

            // Obtener los datos de la editorial seleccionada
            $sql = "SELECT Nombre_editorial FROM editorial WHERE Clv_editorial = $clv_editorial";

            // Ejecutar la consulta
            $result = mysqli_query($conexion, $sql);

            if ($result) {
                // Verificar si se encontró la editorial
                if (mysqli_num_rows($result) > 0) {
                    $editorial = mysqli_fetch_assoc($result);
                    $nombre_editorial = $editorial['Nombre_editorial'];
                } else {
                    echo "<div class='alert alert-danger'>Editorial no encontrado.</div>";
                    exit();
                }
            } else {
                echo "<div class='alert alert-danger'>Error al ejecutar la consulta: " . mysqli_error($conexion) . "</div>";
                exit();
            }
        } else {
            echo "<div class='alert alert-danger'>Parámetro de editorial no recibido.</div>";
            exit();
        }

        // Procesar el formulario de actualización
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nuevo_nombre = $_POST['nombre_editorial'];

            // Llamar al procedimiento almacenado para editar la editorial
            $sql_update = "CALL EditarEditorial($clv_editorial, '$nuevo_nombre')";

            if (mysqli_query($conexion, $sql_update)) {
                echo "<div class='alert alert-success'>Editorial actualizado correctamente.</div>";
                echo "<a href='consultar_editorial.php' class='btn btn-primary mt-3'>Volver a la lista de editoriales</a>";
                mysqli_close($conexion);
                exit();
            } else {
                echo "<div class='alert alert-danger'>Error al actualizar la editorial: " . mysqli_error($conexion) . "</div>";
            }
        }

        mysqli_close($conexion);
        ?>

        <!-- Formulario de edición -->
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?clv_editorial=' . $clv_editorial; ?>" method="post">
            <div class="form-group">
                <label for="nombre_editorial">Nombre de la editorial</label>
                <input type="text" class="form-control" id="nombre_editorial" name="nombre_editorial" value="<?php echo $nombre_editorial; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="consultar_editorial.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
