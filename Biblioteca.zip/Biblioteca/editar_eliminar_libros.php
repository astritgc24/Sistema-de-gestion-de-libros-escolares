<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Metadatos, enlaces a CSS y scripts -->
</head>

<body>
    <!-- Contenido del cuerpo de la página -->
    <script>
        // Script para confirmar y eliminar libro
        $(document).ready(function () {
            $(".delete-book").click(function (e) {
                e.preventDefault();
                var isbn = $(this).data("isbn");
                var titulo = $(this).data("titulo");
                confirmDelete(titulo, isbn);
            });

            function confirmDelete(titulo, isbn) {
                $.ajax({
                    type: "POST",
                    url: "eliminarLibroEspañol.php",
                    data: { isbn: isbn },
                    success: function (response) {
                        if (response.trim() === "success") {
                            // Éxito al eliminar
                            $("#row-" + isbn).remove(); // Eliminar la fila de la tabla
                            Swal.fire({
                                title: '¡Eliminado!',
                                text: 'El libro se eliminó correctamente.',
                                icon: 'success'
                            });
                        } else if (response.trim() === "prestamos") {
                            // No se puede eliminar debido a préstamos
                            Swal.fire({
                                title: 'Error',
                                text: 'No se puede eliminar el libro porque tiene préstamos asociados.',
                                icon: 'error'
                            });
                        } else {
                            // Otro tipo de error
                            Swal.fire({
                                title: 'Error',
                                text: 'Hubo un problema al intentar eliminar el libro.',
                                icon: 'error'
                            });
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr, status, error); // Mostrar detalles del error en consola
                        Swal.fire({
                            title: 'Error',
                            text: 'Hubo un problema al intentar eliminar el libro.',
                            icon: 'error'
                        });
                    }
                });
            }
        });
    </script>
</body>

</html>
