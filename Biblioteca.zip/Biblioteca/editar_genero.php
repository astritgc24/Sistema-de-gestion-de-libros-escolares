<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Género</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Editar Género</h2>

        <?php
        // Incluir el archivo de conexión
        include("conexion/conectar-mysql.php");

        // Verificar si se recibió el parámetro clv_genero
        if (isset($_GET['clv_genero'])) {
            $clv_genero = $_GET['clv_genero'];

            // Obtener los datos del género seleccionado
            $sql = "SELECT Nombre_genero FROM genero WHERE Clv_genero = $clv_genero";
            $result = mysqli_query($conexion, $sql);

            if (mysqli_num_rows($result) > 0) {
                $genero = mysqli_fetch_assoc($result);
                $nombre_genero = $genero['Nombre_genero'];
            } else {
                echo "<div class='alert alert-danger'>Género no encontrado.</div>";
                exit();
            }
        } else {
            echo "<div class='alert alert-danger'>Parámetro de género no recibido.</div>";
            exit();
        }

        // Procesar el formulario de actualización
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nuevo_nombre = $_POST['nombre_genero'];

            // Llamar al procedimiento almacenado para editar el género
            $sql_update = "CALL EditarGenero($clv_genero, '$nuevo_nombre')";

            if (mysqli_query($conexion, $sql_update)) {
                echo "<div class='alert alert-success'>Género actualizado correctamente.</div>";
                echo "<a href='consultar_genero.php' class='btn btn-primary mt-3'>Volver a la lista de géneros</a>";
                mysqli_close($conexion);
                exit();
            } else {
                echo "<div class='alert alert-danger'>Error al actualizar el género: " . mysqli_error($conexion) . "</div>";
            }
        }

        mysqli_close($conexion);
        ?>

        <!-- Formulario de edición -->
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?clv_genero=' . $clv_genero; ?>" method="post">
            <div class="form-group">
                <label for="nombre_genero">Nombre del Género</label>
                <input type="text" class="form-control" id="nombre_genero" name="nombre_genero" value="<?php echo $nombre_genero; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="consultar_genero.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
