<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Editar Libro</h2>

        <?php
        // Incluir el archivo de conexión
        include("conexion/conectar-mysql.php");

        // Verificar si se recibió el parámetro ISBN
        if (isset($_GET['isbn'])) {
            $isbn_original = $_GET['isbn'];

            // Obtener los datos del libro seleccionado
            $sql = "SELECT l.*, e.Nombre_editorial, g.Nombre_genero, s.Nombre_serie
        FROM libro l
        INNER JOIN editorial e ON l.Clv_editorial = e.Clv_editorial
        INNER JOIN genero g ON l.Clv_genero = g.Clv_genero
        LEFT JOIN serie s ON l.Clv_serie = s.Clv_serie
        WHERE l.ISBN = '$isbn_original'";

            // Ejecutar la consulta
            $result = mysqli_query($conexion, $sql);

            if ($result) {
                // Verificar si se encontró el libro
                if (mysqli_num_rows($result) > 0) {
                    $libro = mysqli_fetch_assoc($result);
                } else {
                    echo "<div class='alert alert-danger'>Libro no encontrado.</div>";
                    exit();
                }
            } else {
                echo "<div class='alert alert-danger'>Error al ejecutar la consulta: " . mysqli_error($conexion) . "</div>";
                exit();
            }
        } else {
            echo "<div class='alert alert-danger'>Parámetro ISBN no recibido.</div>";
            exit();
        }

        // Consultar editoriales disponibles
        $sql_editoriales = "SELECT Clv_editorial, Nombre_editorial FROM editorial";
        $result_editoriales = mysqli_query($conexion, $sql_editoriales);

        if (!$result_editoriales) {
            echo "<div class='alert alert-danger'>Error al obtener las editoriales: " . mysqli_error($conexion) . "</div>";
            exit();
        }

        // Consultar géneros disponibles
        $sql_generos = "SELECT Clv_genero, Nombre_genero FROM genero";
        $result_generos = mysqli_query($conexion, $sql_generos);

        if (!$result_generos) {
            echo "<div class='alert alert-danger'>Error al obtener los géneros: " . mysqli_error($conexion) . "</div>";
            exit();
        }

        // Consultar series disponibles
        $sql_series = "SELECT Clv_serie, Nombre_serie FROM serie";
        $result_series = mysqli_query($conexion, $sql_series);

        if (!$result_series) {
            echo "<div class='alert alert-danger'>Error al obtener las series: " . mysqli_error($conexion) . "</div>";
            exit();
        }

        // Obtener los autores actuales del libro
        $sql_autores = "SELECT a.nombre_autor
                        FROM autor a
                        INNER JOIN `libro-autor` la ON a.clv_autor = la.clv_autor
                        WHERE la.ISBN = '$isbn_original'";

        $result_autores = mysqli_query($conexion, $sql_autores);

        $autores = [];
        if ($result_autores) {
            while ($row = mysqli_fetch_assoc($result_autores)) {
                $autores[] = $row['nombre_autor'];
            }
        } else {
            echo "<div class='alert alert-danger'>Error al obtener los autores: " . mysqli_error($conexion) . "</div>";
            exit();
        }

        // Verificar si se envió el formulario de edición
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $nuevo_isbn = mysqli_real_escape_string($conexion, $_POST['isbn']);
            $titulo = mysqli_real_escape_string($conexion, $_POST['titulo']);
            $subtitulo = mysqli_real_escape_string($conexion, $_POST['subtitulo']);
            $editorial = mysqli_real_escape_string($conexion, $_POST['editorial']);
            $genero = mysqli_real_escape_string($conexion, $_POST['genero']);
            $serie = mysqli_real_escape_string($conexion, $_POST['serie']);
            $autores = mysqli_real_escape_string($conexion, $_POST['autores']); // Autores separados por comas

            // Llamar al procedimiento almacenado para actualizar el libro y los autores
            $sql = "CALL EditarISBNLibro('$isbn_original', '$nuevo_isbn', '$titulo', '$subtitulo', $genero, $editorial, $serie, '$autores')";

            $result = mysqli_query($conexion, $sql);

            if ($result) {
                echo "<div class='alert alert-success' role='alert'>Libro actualizado correctamente</div>";
                // Actualizar el ISBN en la URL después de la actualización
                echo "<script>window.location.href = 'editar_libro.php?isbn=$nuevo_isbn';</script>";
            } else {
                echo "<div class='alert alert-danger' role='alert'>Error al actualizar el libro: " . mysqli_error($conexion) . "</div>";
            }
        }
        ?>


        <!-- Formulario de edición -->
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?isbn=' . $isbn_original; ?>" method="post">
            <div class="form-group">
                <label for="isbn">ISBN</label>
                <input type="text" class="form-control" id="isbn" name="isbn" value="<?php echo $libro['ISBN']; ?>" required>
            </div>
            <div class="form-group">
                <label for="titulo">Título</label>
                <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo $libro['Titulo']; ?>" required>
            </div>
            <div class="form-group">
                <label for="subtitulo">Subtítulo</label>
                <input type="text" class="form-control" id="subtitulo" name="subtitulo" value="<?php echo $libro['Subtitulo']; ?>">
            </div>
            <div class="form-group">
                <label for="editorial">Editorial</label>
                <select class="form-control" id="editorial" name="editorial" required>
                    <!-- Opciones de editoriales -->
                    <?php
                    while ($row = mysqli_fetch_assoc($result_editoriales)) {
                        $selected = ($row['Clv_editorial'] == $libro['Clv_editorial']) ? 'selected' : '';
                        echo "<option value='{$row['Clv_editorial']}' $selected>{$row['Nombre_editorial']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="genero">Género</label>
                <select class="form-control" id="genero" name="genero" required>
                    <!-- Opciones de géneros -->
                    <?php
                    while ($row = mysqli_fetch_assoc($result_generos)) {
                        $selected = ($row['Clv_genero'] == $libro['Clv_genero']) ? 'selected' : '';
                        echo "<option value='{$row['Clv_genero']}' $selected>{$row['Nombre_genero']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="serie">Serie</label>
                <select class="form-control" id="serie" name="serie">
                    <!-- Opciones de series -->
                    <option value="">Sin serie</option>
                    <?php
                    while ($row = mysqli_fetch_assoc($result_series)) {
                        $selected = ($row['Clv_serie'] == $libro['Clv_serie']) ? 'selected' : '';
                        echo "<option value='{$row['Clv_serie']}' $selected>{$row['Nombre_serie']}</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="autores">Autores (separados por comas)</label>
                <input type="text" class="form-control" id="autores" name="autores" value="<?php echo implode(',', $autores); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            <a href="mostrarLibros.php" class="btn btn-secondary">Cancelar</a>
        </form>

    </div>
</body>
</html>

<?php
// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>
