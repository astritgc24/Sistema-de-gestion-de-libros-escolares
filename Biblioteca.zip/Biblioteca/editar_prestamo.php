<?php
// Conexión a la base de datos (debes incluir tu lógica de conexión aquí)
include("conexion/conectar-mysql.php");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Definir el número de folio del préstamo que deseas editar
$folio_prestamo = isset($_GET['folio_prestamo']) ? intval($_GET['folio_prestamo']) : 0;
$mensaje = isset($_GET['mensaje']) ? $_GET['mensaje'] : '';

// Consulta SQL para obtener los datos del préstamo y el libro relacionado
$query = "SELECT p.Folio_prestamo, p.Folio_ejemplar,
                 a.Matricula AS MatriculaAlumno, a.Nombre AS NombreAlumno, a.Ap1 AS ApellidoPaterno, a.Ap2 AS ApellidoMaterno,
                 p.Fecha_Prestamo, p.Fecha_Entrega,
                 l.ISBN, l.Titulo, d.Descripcion AS Disciplina,
                 ej.Folio AS FolioEjemplar
          FROM prestamo p
          INNER JOIN alumno a ON p.Matricula = a.Matricula
          INNER JOIN ejemplar ej ON p.Folio_ejemplar = ej.Folio
          INNER JOIN libro l ON ej.ISBN = l.ISBN
          INNER JOIN disciplina d ON l.Disciplina = d.Clv_disciplina
          WHERE p.Folio_prestamo = $folio_prestamo";

$resultado = $conexion->query($query);

// Verificar si la consulta arrojó resultados
if ($resultado) {
    // Obtener el registro del préstamo
    $prestamo = $resultado->fetch_assoc();
} else {
    echo "Error al ejecutar la consulta: " . $conexion->error;
}

// Consulta para obtener la lista de alumnos (para el select)
$query_alumnos = "SELECT Matricula, CONCAT(Nombre, ' ', Ap1, ' ', Ap2) AS NombreCompleto FROM alumno";
$result_alumnos = $conexion->query($query_alumnos);

// Verificar si la consulta de alumnos arrojó resultados
if (!$result_alumnos) {
    echo "Error al obtener la lista de alumnos: " . $conexion->error;
}

// Cerrar conexión
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Préstamo</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <!-- Estilos para el selector de fecha de Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <style>
        .card {
            max-width: 800px;
            margin: auto;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .card-header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
        }
        .card-body {
            padding: 20px;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h1 class="card-title"> Editar Préstamo</h1>
            </div>
            <div class="card-body">
                <?php if ($mensaje): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $mensaje; ?>
                    </div>
                <?php endif; ?>
                <form method="post" action="guardar_edicion_prestamo.php">
                    <input type="hidden" name="folio_prestamo" value="<?php echo $prestamo['Folio_prestamo']; ?>">
                    <input type="hidden" name="folio_ejemplar" value="<?php echo $prestamo['FolioEjemplar']; ?>">

                    <div class="form-group">
                        <label><i class="fas fa-key"></i> Folio del préstamo:</label>
                        <input type="text" class="form-control" value="<?php echo $prestamo['Folio_prestamo']; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-book"></i> Folio del ejemplar:</label>
                        <input type="text" class="form-control" value="<?php echo $prestamo['FolioEjemplar']; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-book-open"></i> Título del libro:</label>
                        <input type="text" class="form-control" value="<?php echo $prestamo['Titulo']; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-layer-group"></i> Disciplina:</label>
                        <input type="text" class="form-control" value="<?php echo $prestamo['Disciplina']; ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="matricula"><i class="fas fa-user"></i> Alumno:</label>
                        <select class="form-control" id="matricula" name="matricula">
                            <?php while ($row = $result_alumnos->fetch_assoc()): ?>
                                <option value="<?php echo $row['Matricula']; ?>" <?php if ($row['Matricula'] == $prestamo['MatriculaAlumno']): ?> selected <?php endif; ?>>
                                    <?php echo $row['NombreCompleto']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="fecha_prestamo"><i class="fas fa-calendar-alt"></i> Fecha de Préstamo:</label>
                        <div class="input-group date" id="datepicker" data-target-input="nearest">
                            <input type="text" class="form-control datetimepicker-input" data-target="#datepicker" name="fecha_prestamo" value="<?php echo $prestamo['Fecha_Prestamo']; ?>"/>
                            <div class="input-group-append" data-target="#datepicker" data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Cambios</button>
                    <a href="consultar_prestamos.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancelar</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Scripts para el selector de fecha de Bootstrap -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/locales/bootstrap-datepicker.es.min.js"></script>
    <script>
        $(function () {
            $('#datepicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
                language: 'es'
            });
        });
    </script>
</body>
</html>
