<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Serie</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }
        h2 {
            margin-bottom: 20px;
            font-weight: bold;
            color: #000; /* Color negro para el título */
            display: flex;
            align-items: center;
        }
        h2 img {
            margin-right: 15px;
            width: 60px; /* Tamaño aumentado del icono */
            height: auto;
        }
        .btn-custom {
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px; /* Espacio entre botones */
            margin-right: 10px; /* Espacio entre botones */
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .back-button {
            margin-top: 10px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
        }
        .alert {
            margin-top: 10px;
            font-size: 16px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>

<div class="container">
    <h2><img src="images/ejemplar.png" alt="icono"> EDITAR SERIE</h2>

    <?php
    // Configuración de la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "biblioteca_escolar";

    // Crear conexión
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Definir variables
    $clv_serie = "";
    $nombre = "";
    $imagen_actual = "";

    // Obtener el Clv_serie de la serie a editar
    if (isset($_GET['clv_serie'])) {
        $clv_serie = $_GET['clv_serie'];

        // Consultar la serie por Clv_serie
        $sql = "SELECT Clv_serie, Nombre_serie, imagen FROM serie WHERE Clv_serie=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $clv_serie); // "i" indica que $clv_serie es un integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $clv_serie = $row['Clv_serie'];
            $nombre = $row['Nombre_serie'];
            $imagen_actual = $row['imagen'];
        } else {
            echo "<div class='alert alert-danger'>No se encontró la serie con Clv_serie: " . htmlspecialchars($clv_serie) . "</div>";
            $conn->close();
            exit;
        }
    } else {
        echo "<div class='alert alert-danger'>Parámetro Clv_serie no especificado.</div>";
        $conn->close();
        exit;
    }

    // Verificar si se ha enviado el formulario de edición
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener datos del formulario
        $clv_serie = $_POST['clv_serie'];
        $nombre = $_POST['nombre'];
        $imagen = $_FILES['imagen'];

        // Verificar si se subió una nueva imagen
        if ($imagen['size'] > 0) {
            $imagen_nombre = $imagen['name'];
            $imagen_temp = $imagen['tmp_name'];
            $imagen_destino = "uploads/" . $imagen_nombre; // Ruta donde se guardará la imagen
            
            // Mover la imagen a la carpeta destino
            if (move_uploaded_file($imagen_temp, $imagen_destino)) {
                // Actualizar datos en la base de datos (incluyendo imagen)
                $sql = "UPDATE serie SET Nombre_serie=?, imagen=? WHERE Clv_serie=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssi", $nombre, $imagen_destino, $clv_serie); // "ssi" indica que son dos strings y un integer
            } else {
                echo "<div class='alert alert-danger'>Error al subir la imagen.</div>";
                $conn->close();
                exit;
            }
        } else {
            // Actualizar solo el nombre de la serie
            $sql = "UPDATE serie SET Nombre_serie=? WHERE Clv_serie=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $nombre, $clv_serie); // "si" indica que son un string y un integer
        }

        // Ejecutar la consulta preparada
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Serie actualizada exitosamente.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error al actualizar la serie: " . $conn->error . "</div>";
        }
    }

    // Cerrar conexión
    $conn->close();
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?clv_serie=" . urlencode($clv_serie)); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nombre">Nombre de la Serie:</label>
            <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo htmlspecialchars($nombre); ?>" required>
            <input type="hidden" name="clv_serie" value="<?php echo htmlspecialchars($clv_serie); ?>">
        </div>
        <div class="form-group">
            <label for="imagen">Imagen de la Serie:</label>
            <input type="file" class="form-control-file" id="imagen" name="imagen">
        </div>
        <?php if (!empty($imagen_actual)) : ?>
            <div class="form-group">
                <p>Imagen actual:</p>
                <img src="<?php echo htmlspecialchars($imagen_actual); ?>" alt="Imagen Actual" style="max-width: 100%; height: auto;">
            </div>
        <?php endif; ?>
        <button type="submit" class="btn btn-custom">Guardar Cambios</button>
        <a href="series.php" class="btn btn-secondary back-button">Volver a Series</a>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
