<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Nueva Editorial</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Registro de editoriales</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        include("conexion/conectar-mysql.php");

                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $nombre_editorial = $_POST['nombre_editorial'];

                            // Verificar si el campo de nombre de editorial está vacío
                            if (!empty($nombre_editorial)) {
                                $sql = "CALL RegistrarEditorial('$nombre_editorial')";
                                if (mysqli_query($conexion, $sql)) {
                                    echo "<div class='alert alert-success'>Editorial registrada exitosamente.</div>";
                                    // Redireccionar a la página de consulta de editoriales (cambiar la URL según sea necesario)
                                    header("Location: consultar_editorial.php");
                                    exit(); // Asegúrate de que el script se detenga después de la redirección
                                } else {
                                    echo "<div class='alert alert-danger'>Problemas al registrar la editorial, verifique de nuevo.</div>";
                                }
                            } else {
                                echo "<div class='alert alert-warning'>Por favor, complete todos los campos.</div>";
                            }
                        }
                        ?>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <div class="form-group">
                                <label for="nombre_editorial">Nombre de la editorial</label>
                                <input type="text" class="form-control" id="nombre_editorial" name="nombre_editorial" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Registrar editorial</button>
                            <button type="reset" class="btn btn-secondary">Limpiar Campos</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
