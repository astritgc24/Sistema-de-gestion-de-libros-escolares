<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

// Verificar si se recibió el parámetro folio
if (isset($_GET['folio'])) {
    // Obtener el folio desde la URL
    $folio = $_GET['folio'];

    // Llamar al procedimiento almacenado para eliminar el ejemplar
    $sql = "CALL EliminarEjemplar(?)";  // Usamos ? como marcador de posición para el parámetro

    // Preparar la sentencia
    $stmt = mysqli_prepare($conexion, $sql);

    // Verificar si la preparación de la sentencia fue exitosa
    if ($stmt === false) {
        echo "Error al preparar la consulta: " . mysqli_error($conexion);
        exit();
    }

    // Vincular parámetros
    mysqli_stmt_bind_param($stmt, 'i', $folio);  // 'i' indica que $folio es un entero

    // Ejecutar la sentencia
    if (mysqli_stmt_execute($stmt)) {
        // Éxito en la ejecución, redireccionar de vuelta a listaLibros.php
        mysqli_stmt_close($stmt);
        mysqli_close($conexion);
        header('Location: listaLibrosTutorias.php');
        exit();
    } else {
        // Error en la ejecución
        echo "Error al eliminar el ejemplar: " . mysqli_stmt_error($stmt);
    }
} else {
    // Si no se recibió el parámetro folio
    echo "Parámetro 'folio' no recibido";
}

// Cerrar conexión
mysqli_close($conexion);


    // En tu archivo eliminarEjemplarEspañol.php
    include("conexion/conectar-mysql.php");

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['folio'])) {
        $folio = $_GET['folio'];
        $sql = "DELETE FROM libros WHERE Folio = '$folio'";

        if (mysqli_query($conexion, $sql)) {
            // Éxito al eliminar
            echo json_encode(array("success" => true));
        } else {
            // Error al eliminar
            echo json_encode(array("success" => false, "error" => mysqli_error($conexion)));
        }
    } else {
        echo json_encode(array("success" => false, "error" => "Parámetros no válidos"));
    }

    mysqli_close($conexion);
?>



