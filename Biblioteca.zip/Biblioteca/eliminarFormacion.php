<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

if (isset($_GET['isbn'])) {
    $isbn = $_GET['isbn'];

    // Verificar si el libro tiene ejemplares asociados
    $queryEjemplares = "SELECT COUNT(*) AS total_ejemplares FROM ejemplar WHERE ISBN = '$isbn'";
    $resultEjemplares = mysqli_query($conexion, $queryEjemplares);
    $rowEjemplares = mysqli_fetch_assoc($resultEjemplares);
    $total_ejemplares = $rowEjemplares['total_ejemplares'];

    if ($total_ejemplares > 0) {
        $mensaje = "No se puede eliminar el libro porque tiene ejemplares asociados.";
        $icono = "error";
    } else {
        // Eliminar registros en la tabla libro-autor
        $deleteLibroAutorQuery = "DELETE FROM `libro-autor` WHERE ISBN = '$isbn'";
        if (mysqli_query($conexion, $deleteLibroAutorQuery)) {
            // Luego de eliminar los registros en libro-autor, proceder a eliminar el libro
            $deleteLibroQuery = "DELETE FROM libro WHERE ISBN = '$isbn'";
            if (mysqli_query($conexion, $deleteLibroQuery)) {
                $mensaje = "Libro eliminado con éxito.";
                $icono = "success";
            } else {
                $mensaje = "Error al eliminar el libro: " . mysqli_error($conexion);
                $icono = "error";
            }
        } else {
            $mensaje = "Error al eliminar los registros en libro-autor: " . mysqli_error($conexion);
            $icono = "error";
        }
    }

    // Cerrar conexión
    mysqli_close($conexion);

    // Redirigir con el mensaje de éxito o error
    header("Location: mostrarFormacionEliminar.php?mensaje=" . urlencode($mensaje) . "&icono=" . $icono);
    exit();
} else {
    header("Location: mostrarFormacionEliminar.php?mensaje=" . urlencode("ISBN no proporcionado.") . "&icono=error");
    exit();
}
?>
