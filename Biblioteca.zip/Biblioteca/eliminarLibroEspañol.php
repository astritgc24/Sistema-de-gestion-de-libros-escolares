<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

// Verificar si se ha enviado la solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener el ISBN del libro a eliminar
    $isbn = $_POST['isbn'];

    // Llamar al procedimiento almacenado para eliminar el libro y sus ejemplares
    $sql = "CALL eliminar_libro_y_ejemplares(?)";
    
    // Preparar la consulta
    if ($stmt = mysqli_prepare($conexion, $sql)) {
        // Vincular parámetros
        mysqli_stmt_bind_param($stmt, 's', $isbn);

        // Ejecutar la consulta
        if (mysqli_stmt_execute($stmt)) {
            echo "success";
        } else {
            echo "error";
        }

        // Cerrar la declaración
        mysqli_stmt_close($stmt);
    } else {
        echo "error";
    }

    // Cerrar conexión
    mysqli_close($conexion);
} else {
    echo "error";
}
?>
