<?php
// Incluir archivo de conexión a la base de datos
include("conexion/conectar-mysql.php");

// Conectar a la base de datos
$conexion = mysqli_connect($servidor, $usuario, $password, $baseDatos);
if (!$conexion) {
    die("Error al conectar con la base de datos: " . mysqli_connect_error());
}

// Obtener la matrícula del alumno a eliminar
$matricula = $_POST['matricula'];

// Verificar si el alumno tiene préstamos asociados
$verificar_prestamos = "SELECT COUNT(*) AS total FROM prestamo WHERE Matricula = '$matricula'";
$resultado_verificacion = mysqli_query($conexion, $verificar_prestamos);
$fila_verificacion = mysqli_fetch_assoc($resultado_verificacion);

if ($fila_verificacion['total'] > 0) {
    // El alumno tiene préstamos, no se puede eliminar
    header("Location: mostrarAlumnos.php?error=No se puede eliminar el alumno porque tiene préstamos asociados.");
} else {
    // El alumno no tiene préstamos, proceder con la eliminación
    $eliminar_alumno = "DELETE FROM alumno WHERE Matricula = '$matricula'";
    if (mysqli_query($conexion, $eliminar_alumno)) {
        header("Location: mostrarAlumnos.php?success=Alumno eliminado exitosamente.");
    } else {
        header("Location: mostrarAlumnos.php?error=Error al eliminar el alumno.");
    }
}

// Cerrar la conexión
mysqli_close($conexion);
exit();
?>
