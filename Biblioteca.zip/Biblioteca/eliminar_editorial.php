<?php
// Incluir el archivo de conexión
include("conexion/conectar-mysql.php");

// Verificar si se recibió el parámetro clv_editorial
if (isset($_GET['clv_editorial'])) {
    $clv_editorial = $_GET['clv_editorial'];

    // Llamar al procedimiento almacenado para eliminar la editorial
    $sql_delete = "CALL EliminarEditorial($clv_editorial)";

    if (mysqli_query($conexion, $sql_delete)) {
        echo "<div class='alert alert-success'>Editorial eliminada correctamente.</div>";
        echo "<a href='consultar_editorial.php' class='btn btn-primary mt-3'>Volver a la lista de editoriales</a>";
        // Redireccionar o mostrar mensaje de éxito
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar la editorial: " . mysqli_error($conexion) . "</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Parámetro de editorial no recibido.</div>";
}

// Cerrar la conexión
mysqli_close($conexion);
?>
