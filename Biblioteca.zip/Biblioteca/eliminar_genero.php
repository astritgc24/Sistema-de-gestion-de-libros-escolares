<?php
// Incluir el archivo de conexión
include("conexion/conectar-mysql.php");

// Verificar si se recibió el parámetro clv_genero correctamente
if (isset($_GET['clv_genero'])) {
    $clv_genero = $_GET['clv_genero'];

    // Llamar al procedimiento almacenado para eliminar el género
    $sql_delete = "CALL EliminarGenero($clv_genero)";

    if (mysqli_query($conexion, $sql_delete)) {
        echo "<div class='alert alert-success'>Género eliminado correctamente.</div>";
        echo "<a href='consultar_genero.php' class='btn btn-primary mt-3'>Volver a la lista de géneros</a>";
        // Redireccionar o mostrar mensaje de éxito
    } else {
        echo "<div class='alert alert-danger'>Error al eliminar el género: " . mysqli_error($conexion) . "</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Parámetro de eliminación no recibido correctamente.</div>";
}

// Cerrar la conexión
mysqli_close($conexion);
?>
