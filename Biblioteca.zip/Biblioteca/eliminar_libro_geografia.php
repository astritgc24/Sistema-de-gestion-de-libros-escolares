<?php
include("conexion/conectar-mysql.php");

if (isset($_GET['isbn'])) {
    $isbn = $_GET['isbn'];

    // Preparar y ejecutar el procedimiento almacenado
    $stmt = mysqli_prepare($conexion, "CALL EliminarLibro(?)");
    mysqli_stmt_bind_param($stmt, "s", $isbn);
    mysqli_stmt_execute($stmt);

    // Comprobar si el libro fue eliminado
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        $mensaje = "El libro ha sido eliminado correctamente.";
        $icono = "success";
    } else {
        $mensaje = "No se pudo eliminar el libro. Puede estar referenciado por ejemplares o préstamos.";
        $icono = "error";
    }

    mysqli_stmt_close($stmt);

    // Redirigir de vuelta a la página de lista de libros con un mensaje de resultado
    header("Location: mostrarGeografia.php?mensaje=" . urlencode($mensaje) . "&icono=" . $icono);
    exit();
} else {
    // Si no se proporciona ISBN, redirigir a la página de lista de libros
    header("Location: mostrarGeografia.php");
    exit();
}
?>