<?php
// Incluir archivo de conexión a la base de datos
include 'conexion/conectar-mysql.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $folio_prestamo = $_POST['folio_prestamo'];

    // Llamada al procedimiento almacenado
    $query = "CALL eliminar_prestamo(?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param('i', $folio_prestamo);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'El préstamo ha sido eliminado.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo eliminar el préstamo. Inténtalo nuevamente.']);
    }

    $stmt->close();
    $conexion->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Solicitud inválida.']);
}
?>
