<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Serie</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }
        h2 {
            margin-bottom: 20px;
            font-weight: bold;
            color: #000; /* Color negro para el título */
            display: flex;
            align-items: center;
        }
        h2 img {
            margin-right: 15px;
            width: 60px; /* Tamaño aumentado del icono */
            height: auto;
        }
        .btn-custom {
            background-color: #dc3545; /* Color rojo para botones de eliminar */
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px; /* Espacio entre botones */
            margin-right: 10px; /* Espacio entre botones */
        }
        .btn-custom:hover {
            background-color: #c82333; /* Color de hover más oscuro */
        }
        .back-button {
            margin-top: 10px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
        }
        .alert {
            margin-top: 10px;
            font-size: 16px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>

<div class="container">
    <h2><img src="images/ejemplar.png" alt="icono"> ELIMINAR SERIE</h2>

    <?php
    // Verificar si se recibió el parámetro 'clv_serie' por GET
    if (isset($_GET['clv_serie'])) {
        // Obtener el ID de la serie a eliminar
        $clv_serie = $_GET['clv_serie'];

        // Configuración de la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "biblioteca_escolar";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Eliminar la serie de la base de datos
        $sql = "DELETE FROM serie WHERE clv_serie=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $clv_serie); // 's' indica que $clv_serie es un string (clave de serie)

        try {
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>La serie fue eliminada correctamente.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error al intentar eliminar la serie: " . $conn->error . "</div>";
            }
        } catch (mysqli_sql_exception $e) {
            $errorCode = $e->getCode();
            if ($errorCode == 1451) {
                echo "<div class='alert alert-danger'>Error: No se puede eliminar la serie porque está siendo utilizada por libros.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
            }
        }

        // Cerrar conexión
        $conn->close();
    } else {
        echo "<div class='alert alert-danger'>No se recibió el parámetro 'clv_serie' para eliminar la serie.</div>";
    }
    ?>

    <a href="series.php" class="btn btn-secondary back-button">Volver a Tabla de Series</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
