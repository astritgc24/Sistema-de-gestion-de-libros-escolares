<?php

// Función para obtener los nombres de los autores de un libro dado
function obtenerAutores($isbn, $conexion) {
    $autores = array();

    // Consulta SQL para obtener los nombres de los autores de un libro
    $sql = "SELECT autor.nombre_autor 
            FROM autor
            INNER JOIN libro_autor ON autor.clv_autor = libro_autor.clv_autor
            WHERE libro_autor.ISBN = '$isbn'";

    $result = mysqli_query($conexion, $sql);

    if ($result) {
        // Recorrer los resultados y almacenar los nombres de los autores en un array
        while ($row = mysqli_fetch_assoc($result)) {
            $autores[] = $row['nombre_autor'];
        }
        // Devolver los nombres de los autores como una cadena separada por comas
        return implode(', ', $autores);
    } else {
        return "Error al obtener los autores: " . mysqli_error($conexion);
    }
}




// Función para obtener la imagen de la serie de un libro
function obtenerImagenSerie($serie, $conexion) {
    $sql = "SELECT imagen FROM serie WHERE Clv_serie = '$serie'";
    $result = mysqli_query($conexion, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        return $row['imagen'];
    } else {
        return ''; // Devolver cadena vacía si no se encuentra la imagen
    }
}

// Otras funciones adicionales que puedas necesitar

?>



