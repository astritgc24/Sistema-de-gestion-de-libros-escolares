<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Nuevo Género</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3>Registro de géneros</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        include("conexion/conectar-mysql.php");

                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                            $nombre_genero = $_POST['nombre_genero'];

                            // Verificar si el campo de nombre de género está vacío
                            if (!empty($nombre_genero)) {
                                $sql = "CALL RegistrarGenero('$nombre_genero')";
                                if (mysqli_query($conexion, $sql)) {
                                    echo "<div class='alert alert-success'>Género registrado exitosamente.</div>";
                                    // Redireccionar a la página de consulta de géneros (cambiar la URL según sea necesario)
                                    header("location: consultar_genero.php");
                                } else {
                                    echo "<div class='alert alert-danger'>Problemas al registrar el género, verifique de nuevo.</div>";
                                }
                            } else {
                                echo "<div class='alert alert-warning'>Por favor, complete todos los campos.</div>";
                            }
                        }
                        ?>
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <div class="form-group">
                                <label for="nombre_genero">Nombre del Género</label>
                                <input type="text" class="form-control" id="nombre_genero" name="nombre_genero" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Registrar Género</button>
                            <button type="reset" class="btn btn-secondary">Limpiar Campos</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
