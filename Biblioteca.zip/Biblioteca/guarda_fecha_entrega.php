<?php
function actualizarFechaEntrega($clavePrestamo, $folioPrestamo, $fechaEntrega) {
    global $conexion;

    // Llamada al procedimiento almacenado
    $query = "CALL ActualizarFechaEntrega(?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $query);

    // Verificar si hubo un error en la preparación de la sentencia
    if ($stmt === false) {
        echo json_encode(array("status" => "error", "message" => "Error al preparar la consulta: " . mysqli_error($conexion)));
        return;
    }

    // Vincular parámetros
    mysqli_stmt_bind_param($stmt, "iis", $clavePrestamo, $folioPrestamo, $fechaEntrega);

    // Ejecutar la sentencia preparada
    $resultado = mysqli_stmt_execute($stmt);

    // Verificar si se ejecutó correctamente
    if ($resultado === false) {
        echo json_encode(array("status" => "error", "message" => "Error al ejecutar el procedimiento almacenado: " . mysqli_stmt_error($stmt)));
        return;
    }

    // Verificar el número de filas afectadas
    $filasAfectadas = mysqli_stmt_affected_rows($stmt);

    if ($filasAfectadas > 0) {
        echo json_encode(array("status" => "success", "message" => "Fecha de entrega registrada correctamente."));
    } else {
        echo json_encode(array("status" => "error", "message" => "No se realizó ninguna actualización. Verifica los parámetros proporcionados."));
    }

    // Cerrar la sentencia preparada y la conexión
    mysqli_stmt_close($stmt);
    mysqli_close($conexion);
}

?>
