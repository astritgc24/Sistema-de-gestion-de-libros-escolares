<?php
// Conexión a la base de datos (debes incluir tu lógica de conexión aquí)
include("conexion/conectar-mysql.php");

// Verificar conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener datos del formulario
$folio_prestamo = $_POST['folio_prestamo'];
$matricula = $_POST['matricula'];
$fecha_prestamo = $_POST['fecha_prestamo'];

// Actualizar los datos del préstamo en la base de datos
$query = "UPDATE prestamo SET Matricula = ?, Fecha_Prestamo = ? WHERE Folio_prestamo = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("ssi", $matricula, $fecha_prestamo, $folio_prestamo);

if ($stmt->execute()) {
    $mensaje = "Edición exitosa";
    $url = "consultar_prestamos.php?mensaje=" . urlencode($mensaje);
} else {
    $mensaje = "Error al editar el préstamo: " . $stmt->error;
    $url = "editar_prestamo.php?folio_prestamo=$folio_prestamo&mensaje=" . urlencode($mensaje);
}

// Cerrar conexión
$stmt->close();
$conexion->close();

// Redirigir con mensaje
header("Location: $url");
exit;
?>
