<?php
// Incluir archivo de conexión a la base de datos
include 'conexion/conectar-mysql.php';

// Iniciar sesión
session_start();

// Verificar si se recibieron los datos necesarios
if (!isset($_POST['folio_prestamo']) || !isset($_POST['folio_ejemplar']) || !isset($_POST['fecha_entrega'])) {
    $_SESSION['mensaje_error'] = "Error: Datos incompletos.";
    header("Location: registrar_fecha_entrega.php?folio_prestamo=" . $_POST['folio_prestamo'] . "&folio_ejemplar=" . $_POST['folio_ejemplar']);
    exit();
}

// Obtener los datos del formulario
$folioPrestamo = $_POST['folio_prestamo'];
$folioEjemplar = $_POST['folio_ejemplar'];
$fechaEntrega = $_POST['fecha_entrega'];

// Llamada al procedimiento almacenado
$query = "CALL ActualizarFechaEntrega(?, ?, ?)";

// Preparar la consulta
$stmt = mysqli_prepare($conexion, $query);

// Verificar si hubo un error en la preparación de la consulta
if ($stmt === false) {
    $_SESSION['mensaje_error'] = "Error al preparar la consulta: " . mysqli_error($conexion);
    header("Location: registrar_fecha_entregada.php?folio_prestamo=" . $folioPrestamo . "&folio_ejemplar=" . $folioEjemplar);
    exit();
}

// Vincular los parámetros
mysqli_stmt_bind_param($stmt, "iis", $folioPrestamo, $folioEjemplar, $fechaEntrega);

// Ejecutar la consulta
if (mysqli_stmt_execute($stmt)) {
    $_SESSION['mensaje_exito'] = "Fecha de entrega actualizada correctamente.";
} else {
    $_SESSION['mensaje_error'] = "Error al actualizar la fecha de entrega: " . mysqli_error($conexion);
}

// Cerrar la consulta y la conexión
mysqli_stmt_close($stmt);
mysqli_close($conexion);

// Redirigir a la página anterior para mostrar el mensaje
header("Location: consultar_prestamos.php?folio_prestamo=" . $folioPrestamo . "&folio_ejemplar=" . $folioEjemplar);
exit();
?>
