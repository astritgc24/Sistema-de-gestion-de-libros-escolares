<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .btn-pink {
            background-color: #f5c69d;
            color: white;
            border-color: #f5d7bc;
            border-radius: 50px;
            padding: 8px 20px;
            transition: background-color 0.3s ease;
        }
        .btn-pink:hover,
        .btn-pink:focus {
            background-color: #e0b89f;
            color: white;
            border-color: #e0b89f;
        }
        .logo-img {
            height: 90px;
        }
        .logo2-img {
            height: 100px;
            width: 150px;
        }
        .materia-card {
            max-width: 100%;
            background-color: #f5d7bc;
            border: none;
            box-shadow: none;
            height: 180px;
            margin-bottom: 20px;
        }
        .main-title {
            font-family: 'Arial', sans-serif;
            font-size: 2.5rem;
            margin-bottom: 2rem;
        }
        .welcome-text {
            font-size: 1.2rem;
        }
        .custom-btn {
            cursor: pointer;
        }
        .custom-btn img {
            width: 100px;
        }
        .custom-btn:focus {
            outline: none;
        }
        .gen-btn {
            padding: 0;
            border: none;
            background: none;
        }
        .edit-btn {
            padding: 0;
            border: none;
            background: none;
            margin-left: 10px;
        }
        .title-image-container {
            text-align: center;
            margin-bottom: 60px;
            margin-top: 20px;
        }
        .title-image {
            width: 300px;
        }
        body {
            background-color: #f5d7bc;
            margin: 0;
            padding: 0;
        }
        .materia-text {
            margin-top: 10px;
            font-size: 0.9rem;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row bg-light py-2 align-items-center">
            <div class="col-6 d-flex align-items-center">
                <img src="./imagenes/mujer.png" alt="Logo Sec" class="img-fluid mr-3 logo-img">
                <span class="welcome-text">
                    BIENVENID@ MAESTR@ 
                    <?php
                    session_start();
                    if (isset($_SESSION['nombre'])) {
                        echo $_SESSION['nombre'];
                    } else {
                        echo 'Invitado';
                    }
                    ?>
                </span>
            </div>
            <div class="col-6 text-right">
                <a href="#" class="custom-btn gen-btn">
                    <img src="./images/log.png" alt="Géneros" class="img-fluid mr-3 logo2-img">
                </a>
                <a href="#" class="btn-exit-system">
                    <i class="fas fa-power-off fa-lg"></i>
                </a>
            </div>
        </div>
        <div class="row justify-content-center mt-5">
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosArtes.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./imagenes/artes.png" alt="Materia 1" class="img-fluid mt-2">
                        <div class="materia-text">ARTES</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosCiencias.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/cien.png" alt="Materia 2" class="img-fluid mt-2">
                        <div class="materia-text">CIENCIAS</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosEducacion.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/fisica.png" alt="Materia 3" class="img-fluid mt-2">
                        <div class="materia-text">EDUCACION FISICA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosEspañol.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./imagenes/esp.png" alt="Materia 4" class="img-fluid mt-2">
                        <div class="materia-text">ESPAÑOL</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosFormacion.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/principios-morales.png" alt="Materia 5" class="img-fluid mt-2">
                        <div class="materia-text">F.C Y E</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosGeo.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/geo.png" alt="Materia 6" class="img-fluid mt-2">
                        <div class="materia-text">GEOGRAFIA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosHist.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/hist.png" alt="Materia 7" class="img-fluid mt-2">
                        <div class="materia-text">HISTORIA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosIngles.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/hola.png" alt="Materia 8" class="img-fluid mt-2">
                        <div class="materia-text">INGLES</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosMath.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/herramientas.png" alt="Materia 9" class="img-fluid mt-2">
                        <div class="materia-text">MATEMATICAS</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosTec.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./imagenes/tecnologia.png" alt="Materia 10" class="img-fluid mt-2">
                        <div class="materia-text">TECNOLOGIA</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="listaLibrosTutorias.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./imagenes/consultor.png" alt="Materia 11" class="img-fluid mt-2">
                        <div class="materia-text">TUTORIAS</div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-4 mb-2">
                <div class="card materia-card" data-url="consultar_prestamos.php">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <img src="./images/leer.png" alt="Materia 12" class="img-fluid mt-2">
                        <div class="materia-text">PRESTAMOS</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="bg-white py-3">
        <div class="container-fluid">
            <div class="row justify-content-end">
                <div class="col-auto">
                <a href="mostrar_libros_y_prestamos.php" class="btn btn-pink mr-2">Reporte</a>
                    <a href="consultar_editorial.php" class="btn btn-pink mr-2">Editoriales</a>
                    <a href="consultar_genero.php" class="btn btn-pink mr-2">Géneros</a>
                    <a href="series.php" class="btn btn-pink">Series</a>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <script src="./js/main.js"></script>
</body>
</html>
