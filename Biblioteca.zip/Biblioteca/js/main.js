// CUANDO SE PULSA EN EL BOTON DE INICIO DE SESION REDIRIJE A LA SIGUIENTE PAGINA

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        window.location.href = 'inicio.html'; // Replace with your desired URL
    });
});



//LA ALERTA QUE NOS DA AL PRESIONAR EL BOTON DE CERRAR SESION
	document.addEventListener('DOMContentLoaded', function() {
		const logoutButton = document.querySelector('.btn-exit-system');
	
		logoutButton.addEventListener('click', function(event) {
			event.preventDefault();
			Swal.fire({
				title: '¿Estás seguro de que deseas cerrar sesión?',
				icon: 'warning',
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Sí, cerrar sesión',
				cancelButtonText: 'Cancelar'
			}).then((result) => {
				if (result.isConfirmed) {
					// Lógica para cerrar sesión, por ejemplo, redirigir a la página de inicio de sesión
					window.location.href = 'index.html'; // Reemplaza con la URL de la página de inicio de sesión
				}
			});
		});
	});
    
     // SweetAlert para el botón de eliminar
     $(document).on('click', '.btn-delete', function(event) {
        event.preventDefault();
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡No podrás revertir esto!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminarlo'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire(
                    '¡Eliminado!',
                    'El libro ha sido eliminado.',
                    'success'
                )
            }
        })
    });

    document.addEventListener('DOMContentLoaded', function() {
        const materiaCards = document.querySelectorAll('.materia-card');
    
        materiaCards.forEach(card => {
            card.addEventListener('click', function() {
                const url = card.getAttribute('data-url');
                if (url) {
                    window.location.href = url;
                }
            });
        });
    });
    

  


    


	
