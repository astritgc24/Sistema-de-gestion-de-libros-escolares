<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Libros</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/estilo1.css"> <!-- Archivo CSS personalizado para la tabla -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Estilos personalizados adicionales si es necesario */
        body {
            background-color:  hsl(221, 61%, 54%); /* Fondo amarillo tenue */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container-fluid {
            padding-top: 0; /* Eliminar espacio en blanco encima del contenido */
            background-image: url('ima/nuevo.png'); /* Ruta relativa a la carpeta donde se encuentra el archivo CSS */
            background-size: cover; /* Cubrir toda la pantalla */
            background-position: center; /* Centrar la imagen */
        }

        .header-container {
            background-color: #ffffff; /* Fondo blanco para el encabezado */
            padding: 10px;
            border-bottom: 1px solid #ddd; /* Borde inferior del encabezado */
            margin: 0; /* Eliminar margen */
        }

        .nav-links, .nav-icons {
            display: flex;
            align-items: center;
        }

        .nav-links a, .nav-icons a {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            color: #333; /* Color del texto */
            margin: 10px; /* Espacio entre cada enlace */
            text-decoration: none; /* Quitar subrayado de los enlaces */
        }

        .nav-links img, .nav-icons img {
            width: 30px; /* Ancho de la imagen */
            height: auto; /* Altura automática para mantener la proporción */
            margin-bottom: 5px; /* Espacio entre la imagen y el texto */
        }

        .table-icons a {
            color: #dc3545; /* Color del icono de eliminación */
        }

        .custom-table {
            background-color: white; /* Fondo blanco para la tabla */
            border: 1px solid #dee2e6; /* Borde de la tabla */
            border-radius: 8px; /* Bordes redondeados para la tabla */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Sombra ligera */
        }

        .custom-table th, .custom-table td {
            background-color: white; /* Fondo blanco para las celdas */
            border: 1px solid #dee2e6; /* Borde de las celdas */
            color: #333; /* Color del texto */
        }

        .custom-table th {
            background-color: #f8f9fa; /* Fondo ligeramente gris para los encabezados */
        }

        .custom-table td {
            vertical-align: middle; /* Centrar verticalmente el contenido */
        }

        .footer-container {
            background-color: #ffffff; /* Fondo blanco para el pie de página */
            padding: 20px;
            border-top: 1px solid #ddd; /* Borde superior del pie de página */
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .footer-links a {
            color: #333; /* Color del texto de los enlaces en el pie de página */
            margin-right: 10px; /* Margen derecho para los enlaces */
        }

        @media (max-width: 576px) {
            .nav-links {
                flex-direction: column; /* Cambia a disposición vertical en pantallas pequeñas */
                align-items: center; /* Centra verticalmente en pantallas pequeñas */
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Encabezado -->
        <div class="row header-container align-items-center">
            <div class="col-auto nav-links">
                <img id="selected-card-img" src="images/herramientas.png" alt="Pintura" class="img-fluid" style="width: 60px; height: auto;">
            </div>
            <div class="col-auto">
                <h5 class="text-uppercase">MATEMATICAS
                </h5>
                <p class="text-muted mb-0" style="font-size: 12px;">Lista de Libros</p>
            </div>
            <div class="col nav-links justify-content-center">
                <a href="Registrar_mates.php">
                    <img src="imagenes/registrar.png" alt="Registrar" style="width: 30px; height: auto;">
                    <span>Registrar</span>
                </a>
                <a href="mostrarMatematicas.php">
                    <img src="imagenes/editar.png" alt="Editar" style="width: 30px; height: auto;">
                    <span>Editar</span>
                </a>
                <a href="mostrarMatematicasEliminar.php">
                    <img src="imagenes/eliminar.png" alt="Eliminar" style="width: 30px; height: auto;">
                    <span>Eliminar</span>
                </a>
                <a href="refresh.php">
                    <img src="imagenes/actualizar-flecha.png" alt="Actualizar" style="width: 30px; height: auto;">
                    <span>Actualizar</span>
                </a>
            </div>
            <div class="col-auto ml-auto nav-icons">
                <a href="index.html" class="btn-exit-system">
                    <img src="images/log.png" alt="Cerrar sesión" style="width: 100px; height: auto;">
                </a>
            </div>
        </div>
        
        <!-- Contenido principal -->
        <div class="row justify-content-center mt-4">
            <div class="col-10">
                <div class="table-responsive">
                    <table class="table table-bordered custom-table">
                        <thead>
                            <tr>
                                <th scope="col">Folio</th>
                                <th scope="col">ISBN</th>
                                <th scope="col">Título</th>
                                <th scope="col">Subtítulo</th>
                                <th scope="col">Autores</th>
                                <th scope="col">Editorial</th>
                                <th scope="col">Género</th>
                                <th scope="col">Serie</th>
                                <th scope="col">Estado</th>
                                <th scope="col">Acciones</th> <!-- Nuevo campo para acciones -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                include("conexion/conectar-mysql.php");

                                $sql = $sql = "CALL MostrarLibrosMatematicas()";
                                $result = mysqli_query($conexion, $sql);

                                if (!$result) {
                                    echo "<tr><td colspan='11'>Error en la consulta: " . mysqli_error($conexion) . "</td></tr>";
                                } else {
                                    if (mysqli_num_rows($result) > 0) {
                                        while($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $row['Folio'] . "</td>";
                                            echo "<td>" . $row['ISBN'] . "</td>";
                                            echo "<td>" . $row['Titulo_libro'] . "</td>";
                                            echo "<td>" . $row['Subtitulo_libro'] . "</td>";
                                            echo "<td>" . $row['Autores'] . "</td>";
                                            echo "<td>" . $row['Editorial'] . "</td>";
                                            echo "<td>" . $row['Genero'] . "</td>";
                                            echo "<td><img src='" . $row['imagen'] . "' class='img-fluid' style='max-height: 50px;'></td>";
                                            echo "<td>" . $row['Estado'] . "</td>";
                                            echo "<td class='table-icons'>";
                                            if ($row['Estado'] == 'Prestado') {
                                                echo "<a href='#' class='text-danger book-loaned' data-titulo='" . $row['Titulo_libro'] . "'>";
                                                echo "<i class='fas fa-exclamation-circle'></i> ";
                                                echo "</a>";
                                            } else {
                                            echo "<a href='EliminarEjemplarCiencias.php' class='text-danger delete-book' data-folio='" . $row['Folio'] . "'>";
                                            echo "<i class='fas fa-trash-alt'></i> Eliminar";
                                            echo "</a>";
                                            echo "<a href='registrar_prestamo.php?folio=" . $row['Folio'] . "&isbn=" . $row['ISBN'] . "&titulo=" . urlencode($row['Titulo_libro']) . "' class='text-success ml-2' title='Registrar préstamo'>";
                                            echo "<i class='fas fa-book-reader'></i> ";
                                            echo "</a>";
                                            }
                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='11'>No se encontraron libros</td></tr>";
                                    }
                                }
                                mysqli_close($conexion);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

   



    <script>
    $(document).ready(function() {
        // Manejar click en enlaces de eliminación
        $('.delete-book').click(function(e) {
            e.preventDefault(); // Prevenir el comportamiento por defecto del enlace

            var folio = $(this).data('folio'); // Obtener el folio del atributo data

            // Mostrar SweetAlert para confirmar la eliminación
            Swal.fire({
                title: '¿Estás seguro?',
                text: "Esta acción eliminará el ejemplar. Esta acción no se puede deshacer.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminarlo!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redireccionar a eliminarEjemplarEspañol.php con el folio como parámetro
                    window.location.href = 'eliminarMat.php?folio=' + folio;
                }
            });
        });

        // Manejar clic en el botón de actualizar
        $('#btn-refresh').click(function(e) {
            e.preventDefault(); // Prevenir el comportamiento por defecto del enlace
            location.reload(); // Recargar la página actual
        });
    });
    </script>
</body>
</html>
