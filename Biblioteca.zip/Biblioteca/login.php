<?php
session_start(); // Iniciar la sesión

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca_escolar";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$correo = $_POST['email'];
$contraseña = $_POST['password'];

$sql = "SELECT * FROM usuarios WHERE correo = '$correo' AND contraseña = '$contraseña'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc(); // Obtener los datos del usuario
    $_SESSION['nombre'] = $row['nombre']; // Establecer la variable de sesión 'nombre'
    echo 'success';
} else {
    echo 'Correo o contraseña incorrectos';
}

$conn->close();
?>
