<?php
// Incluir archivo de conexión a la base de datos
include("conexion/conectar-mysql.php");

// Conectar a la base de datos
$conexion = mysqli_connect($servidor, $usuario, $password, $baseDatos);
if (!$conexion) {
    die("Error al conectar con la base de datos: " . mysqli_connect_error());
}

// Llamar al procedimiento almacenado para mostrar alumnos
$query = "CALL MostrarAlumnos()";
$resultado = mysqli_query($conexion, $query);

if (!$resultado) {
    die("Error al ejecutar el procedimiento almacenado: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Alumnos</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            color: #000000; /* Color negro para el título */
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .add-alumno {
            text-align: center;
            margin-top: 20px;
        }
        .add-alumno a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #000000; /* Color negro para el botón */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .add-alumno a:hover {
            background-color: #333333; /* Cambio de color al pasar el ratón */
        }
        .add-alumno i {
            margin-right: 10px;
        }
        .alert {
            margin-bottom: 20px;
        }
        .actions {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px; /* Espacio entre los botones */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Listado de Alumnos <i class="fas fa-user-graduate"></i></h2>

        <!-- Mostrar mensajes de éxito o error -->
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['success']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Matrícula</th>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Grado</th>
                    <th>Grupo</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($fila = mysqli_fetch_assoc($resultado)): ?>
                    <tr>
                        <td><?php echo $fila['Matricula']; ?></td>
                        <td><?php echo $fila['Nombre']; ?></td>
                        <td><?php echo $fila['Ap1']; ?></td>
                        <td><?php echo $fila['Ap2']; ?></td>
                        <td><?php echo $fila['Grado']; ?></td>
                        <td><?php echo $fila['Grupo']; ?></td>
                        <td class="actions">
                            <form action="eliminar_alumno.php" method="POST" style="display:inline;">
                                <input type="hidden" name="matricula" value="<?php echo $fila['Matricula']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <!-- Botón para agregar alumno -->
        <div class="add-alumno">
            <a href="alumnos.php"><i class="fas fa-plus-circle"></i> Agregar alumno</a>
            <a href="consultar_prestamos.php"><i></i> Regresar</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>

<?php
// Cerrar la conexión
mysqli_close($conexion);
?>
