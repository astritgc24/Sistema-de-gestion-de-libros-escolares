<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar y eliminar libros</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .nav-links {
            display: flex;
            align-items: center;
        }

        .nav-icons {
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .nav-links a,
        .nav-icons a {
            margin-right: 10px;
        }

        .header-container {
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #f8f9fa;
        }

        .message {
            display: none;
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        body {
            background-image: url('imagenes/fondoModificado.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color:   #b59e6f; /* Fondo amarillo tenue */
            
        }

        .container-fluid {
            padding-top: 0; /* Eliminar espacio encima del contenido */
        }

        .header-container {
            background-color: #ffffff;
            padding: 10px;
            border-bottom: 1px solid #ddd;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-links,
        .nav-icons {
            display: flex;
            align-items: center;
        }

        .nav-links a,
        .nav-icons a {
            display: flex;
            align-items: center;
            text-align: center;
            color: #333;
            margin: 10px;
            text-decoration: none;
        }

        .nav-links img,
        .nav-icons img {
            width: 30px;
            height: auto;
            margin-right: 10px;
        }

        .table-icons a {
            color: #dc3545;
        }

        .custom-table {
            background-color: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .custom-table th,
        .custom-table td {
            background-color: white;
            border: 1px solid #dee2e6;
            color: #333;
        }

        .custom-table th {
            background-color: #f8f9fa;
        }

        .custom-table td {
            vertical-align: middle;
        }

        .footer-container {
            background-color: #ffffff;
            padding: 20px;
            border-top: 1px solid #ddd;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .serie-img {
            width: 40px; /* Ancho de las imágenes de las series */
            height: auto;
        }

        .footer-links a {
            color: #333;
            margin-right: 10px;
        }

        @media (max-width: 576px) {
            .nav-links {
                flex-direction: column;
                align-items: center;
            }
        }

        .btn-yellow {
            background-color: #ffd700;
            color: #333;
            border-color: #ffd700;
            border-radius: 50px;
            margin-right: 10px;
        }

        .btn-yellow:hover {
            background-color: #ffcc00;
        }

        .btn-return {
            background-color: #ffffff;
            border-radius: 50px;
            padding: 5px 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-return img {
            width: 30px;
            height: auto;
        }

        .btn-return:hover {
            background-color: #ffd700;
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row header-container align-items-center">
            <div class="col-auto nav-links">
                <img id="selected-card-img" src="images/geo.png" alt="Pintura" class="img-fluid" style="width: 70px; height: auto;">
            </div>
            <div class="col-auto">
                <h5 class="text-uppercase">GEOGRAFIA</h5>
            </div>
            <div class="col nav-links justify-content-center">
                <img src="imagenes/eliminar.png" alt="Registrar" class="img-fluid" style="width: 70px; height: auto;">
                <h1>ELIMINAR</h1>
            </div>
            <div class="col-auto ml-auto nav-icons">
                <a href="index.html" class="btn-exit-system">
                    <img src="images/log.png" alt="Cerrar sesión" style="width: 130px; height: auto;">
                </a>
            </div>
        </div>

        <div class="row justify-content-center mt-4">
            <div class="col-10">
                <div class="table-responsive">
                    <table class="table custom-table">
                        <thead>
                            <tr>
                                <th scope="col">ISBN</th>
                                <th scope="col">Título</th>
                                <th scope="col">Subtítulo</th>
                                <th scope="col">Autores</th>
                                <th scope="col">Editorial</th>
                                <th scope="col">Género</th>
                                <th scope="col">Serie</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                // Incluir archivo de conexión
                                include("conexion/conectar-mysql.php");

                                // Consulta para obtener la lista de libros con autores, editorial, género y serie
                                $sql = "SELECT l.ISBN, l.Titulo, l.Subtitulo, 
                                GROUP_CONCAT(a.nombre_autor SEPARATOR ', ') AS Autores, 
                                e.Nombre_editorial AS Editorial, 
                                g.Nombre_genero AS Genero, 
                                s.imagen AS ImagenSerie 
                                FROM libro l
                                LEFT JOIN `libro-autor` la ON l.ISBN = la.ISBN
                                LEFT JOIN autor a ON la.clv_autor = a.clv_autor
                                LEFT JOIN editorial e ON l.Editorial = e.Clv_editorial
                                LEFT JOIN genero g ON l.Genero = g.Clv_genero
                                LEFT JOIN serie s ON l.Serie = s.Clv_serie
                                WHERE l.Disciplina = '5'
                                GROUP BY l.ISBN";

                                $result = mysqli_query($conexion, $sql);

                                if (!$result) {
                                    echo "<tr><td colspan='8'>Error en la consulta: " . mysqli_error($conexion) . "</td></tr>";
                                } else {
                                    if (mysqli_num_rows($result) > 0) {
                                        // Mostrar los datos obtenidos
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr id='row-" . $row['ISBN'] . "' onclick='confirmDelete(\"" . $row['ISBN'] . "\")'>";
                                            echo "<td>" . $row['ISBN'] . "</td>";
                                            echo "<td>" . $row['Titulo'] . "</td>";
                                            echo "<td>" . ($row['Subtitulo'] ? $row['Subtitulo'] : '-') . "</td>";
                                            echo "<td>" . $row['Autores'] . "</td>";
                                            echo "<td>" . $row['Editorial'] . "</td>";
                                            echo "<td>" . $row['Genero'] . "</td>";
                                            echo "<td>";
                                            // Verificar si la imagen de la serie está definida
                                            if (isset($row['ImagenSerie']) && !empty($row['ImagenSerie'])) {
                                                echo "<img src='" . $row['ImagenSerie'] . "' class='serie-img' alt='Imagen de Serie'>";
                                            } else {
                                                echo "Sin imagen";
                                            }
                                           
                                            
                                        }
                                    } else {
                                        echo "<tr><td colspan='8'>No se encontraron libros</td></tr>";
                                    }
                                }

                                // Cerrar conexión
                                mysqli_close($conexion);
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        function confirmDelete(isbn) {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡No podrás revertir esto!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminarlo',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'eliminarGeografia.php?isbn=' + isbn;
                }
            });
        }

        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            const mensaje = urlParams.get('mensaje');
            const icono = urlParams.get('icono');

            if (mensaje && icono) {
                Swal.fire({
                    title: icono === 'success' ? 'Éxito' : 'Error',
                    text: mensaje,
                    icon: icono,
                    confirmButtonText: 'Aceptar'
                });
            }
        });
    </script>
</body>

</html>