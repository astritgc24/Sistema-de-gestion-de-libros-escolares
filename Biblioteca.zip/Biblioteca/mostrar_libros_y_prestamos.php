<?php
// Incluir FPDF
require('fpdf186(1)/fpdf.php');

// Incluir archivo de conexión a la base de datos
include('conexion/conectar-mysql.php');

// Crear objeto FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Añadir logo (ajusta la ruta según donde tengas el logo)
$pdf->Image('images/log.png', 10, 1, 30);

// Configurar fuentes y texto para el título
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 10, utf8_decode('Reporte de Libros, Préstamos, Series, Géneros y Editoriales'), 0, 1, 'C');

// Salto de línea
$pdf->Ln(10);

// --- Tabla de Libros Disponibles ---
// Posición inicial de la tabla de libros disponibles
$posX_libros = 10;
$posY_libros = $pdf->GetY();

// Consulta para obtener libros disponibles
$query_libros = "
    SELECT e.Folio, e.ISBN, l.Titulo, l.Subtitulo, 
           GROUP_CONCAT(a.nombre_autor SEPARATOR ', ') AS autores,
           g.Nombre_genero AS genero, d.Descripcion AS disciplina, s.Nombre_serie AS serie,
           ed.Nombre_editorial AS editorial
    FROM ejemplar e
    INNER JOIN libro l ON e.ISBN = l.ISBN
    LEFT JOIN `libro-autor` la ON l.ISBN = la.ISBN
    LEFT JOIN autor a ON la.clv_autor = a.clv_autor
    LEFT JOIN genero g ON l.Genero = g.Clv_genero
    LEFT JOIN disciplina d ON l.Disciplina = d.Clv_disciplina
    LEFT JOIN serie s ON l.Serie = s.Clv_serie
    LEFT JOIN editorial ed ON l.Editorial = ed.Clv_editorial
    WHERE e.Estado = 'Disponible'
    GROUP BY e.Folio
";

$result_libros = mysqli_query($conexion, $query_libros);

// Verificar si hubo errores en la consulta
if (!$result_libros) {
    die("Error al ejecutar la consulta de libros: " . mysqli_error($conexion));
}

// Mostrar tabla de libros disponibles
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_libros, $posY_libros);
$pdf->Cell(8, 6, utf8_decode('Folio'), 1, 0, 'C');
$pdf->Cell(20, 6, 'ISBN', 1, 0, 'C');
$pdf->Cell(25, 6, utf8_decode('Título'), 1, 0, 'C');
$pdf->Cell(25, 6, utf8_decode('Subtítulo'), 1, 0, 'C');
$pdf->Cell(28, 6, utf8_decode('Autores'), 1, 0, 'C');
$pdf->Cell(15, 6, utf8_decode('Género'), 1, 0, 'C');
$pdf->Cell(18, 6, utf8_decode('Disciplina'), 1, 0, 'C');
$pdf->Cell(25, 6, utf8_decode('Serie'), 1, 0, 'C');
$pdf->Cell(30, 6, utf8_decode('Editorial'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_libros)) {
    $pdf->SetX($posX_libros);
    $pdf->Cell(8, 6, utf8_decode($row['Folio']), 1, 0, 'C');
    $pdf->Cell(20, 6, utf8_decode($row['ISBN']), 1, 0, 'C');
    $pdf->Cell(25, 6, utf8_decode(substr($row['Titulo'], 0, 25)), 1, 0, 'L');
    $pdf->Cell(25, 6, utf8_decode(substr($row['Subtitulo'], 0, 25)), 1, 0, 'L');
    $pdf->Cell(28, 6, utf8_decode(substr($row['autores'], 0, 28)), 1, 0, 'L');
    $pdf->Cell(15, 6, utf8_decode(substr($row['genero'], 0, 15)), 1, 0, 'L');
    $pdf->Cell(18, 6, utf8_decode(substr($row['disciplina'], 0, 18)), 1, 0, 'L');
    $pdf->Cell(25, 6, utf8_decode(substr($row['serie'], 0, 25)), 1, 0, 'L');
    $pdf->Cell(30, 6, utf8_decode(substr($row['editorial'], 0, 30)), 1, 1, 'L');
}

// --- Tabla de Préstamos ---
// Posición inicial de la tabla de préstamos
$posX_prestamos = 10;
$posY_prestamos = $pdf->GetY() + 10;

// Consulta para obtener préstamos
$query_prestamos = "
    SELECT p.Folio_prestamo, p.Folio_ejemplar, e.ISBN, l.Titulo, d.Descripcion AS disciplina,
           p.Fecha_Prestamo, p.Fecha_Entrega
    FROM prestamo p
    INNER JOIN ejemplar e ON p.Folio_ejemplar = e.Folio
    INNER JOIN libro l ON e.ISBN = l.ISBN
    INNER JOIN disciplina d ON l.Disciplina = d.Clv_disciplina
";

$result_prestamos = mysqli_query($conexion, $query_prestamos);

// Verificar si hubo errores en la consulta
if (!$result_prestamos) {
    die("Error al ejecutar la consulta de préstamos: " . mysqli_error($conexion));
}

// Mostrar tabla de préstamos realizados
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_prestamos, $posY_prestamos);
$pdf->Cell(20, 6, utf8_decode('Folio_p'), 1, 0, 'C');
$pdf->Cell(20, 6, utf8_decode('Folio_e'), 1, 0, 'C');
$pdf->Cell(15, 6, 'ISBN', 1, 0, 'C');
$pdf->Cell(35, 6, utf8_decode('Título'), 1, 0, 'C');
$pdf->Cell(25, 6, utf8_decode('Disciplina'), 1, 0, 'C');
$pdf->Cell(30, 6, utf8_decode('Fecha Préstamo'), 1, 0, 'C');
$pdf->Cell(30, 6, utf8_decode('Fecha Entrega'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_prestamos)) {
    $pdf->SetX($posX_prestamos);
    $pdf->Cell(20, 6, utf8_decode($row['Folio_prestamo']), 1, 0, 'C');
    $pdf->Cell(20, 6, utf8_decode($row['Folio_ejemplar']), 1, 0, 'C');
    $pdf->Cell(15, 6, utf8_decode($row['ISBN']), 1, 0, 'C');
    $pdf->Cell(35, 6, utf8_decode(substr($row['Titulo'], 0, 35)), 1, 0, 'L');
    $pdf->Cell(25, 6, utf8_decode(substr($row['disciplina'], 0, 25)), 1, 0, 'L');
    $pdf->Cell(30, 6, utf8_decode($row['Fecha_Prestamo']), 1, 0, 'C');
    $pdf->Cell(30, 6, utf8_decode($row['Fecha_Entrega']), 1, 1, 'C');
}

// --- Tabla de Series ---
// Posición inicial de la tabla de series
$posX_series = 10;
$posY_series = $pdf->GetY() + 10;

// Consulta para obtener series
$query_series = "
    SELECT Clv_serie, Nombre_serie
    FROM serie
";

$result_series = mysqli_query($conexion, $query_series);

// Verificar si hubo errores en la consulta
if (!$result_series) {
    die("Error al ejecutar la consulta de series: " . mysqli_error($conexion));
}

// Mostrar tabla de series
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_series, $posY_series);
$pdf->Cell(30, 6, utf8_decode('Clave Serie'), 1, 0, 'C');
$pdf->Cell(160, 6, utf8_decode('Nombre Serie'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_series)) {
    $pdf->SetX($posX_series);
    $pdf->Cell(30, 6, utf8_decode($row['Clv_serie']), 1, 0, 'C');
    $pdf->Cell(160, 6, utf8_decode(substr($row['Nombre_serie'], 0, 160)), 1, 1, 'L');
}

// --- Tabla de Géneros ---
// Posición inicial de la tabla de géneros
$posX_generos = 10;
$posY_generos = $pdf->GetY() + 10;

// Consulta para obtener géneros
$query_generos = "
    SELECT Clv_genero, Nombre_genero
    FROM genero
";

$result_generos = mysqli_query($conexion, $query_generos);

// Verificar si hubo errores en la consulta
if (!$result_generos) {
    die("Error al ejecutar la consulta de géneros: " . mysqli_error($conexion));
}

// Mostrar tabla de géneros
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_generos, $posY_generos);
$pdf->Cell(30, 6, utf8_decode('Clave Género'), 1, 0, 'C');
$pdf->Cell(160, 6, utf8_decode('Nombre Género'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_generos)) {
    $pdf->SetX($posX_generos);
    $pdf->Cell(30, 6, utf8_decode($row['Clv_genero']), 1, 0, 'C');
    $pdf->Cell(160, 6, utf8_decode(substr($row['Nombre_genero'], 0, 160)), 1, 1, 'L');
}

// --- Tabla de Editoriales ---
// Posición inicial de la tabla de editoriales
$posX_editoriales = 10;
$posY_editoriales = $pdf->GetY() + 10;

// Consulta para obtener editoriales
$query_editoriales = "
    SELECT Clv_editorial, Nombre_editorial
    FROM editorial
";

$result_editoriales = mysqli_query($conexion, $query_editoriales);

// Verificar si hubo errores en la consulta
if (!$result_editoriales) {
    die("Error al ejecutar la consulta de editoriales: " . mysqli_error($conexion));
}

// Mostrar tabla de editoriales
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_editoriales, $posY_editoriales);
$pdf->Cell(30, 6, utf8_decode('Clave Editorial'), 1, 0, 'C');
$pdf->Cell(160, 6, utf8_decode('Nombre Editorial'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_editoriales)) {
    $pdf->SetX($posX_editoriales);
    $pdf->Cell(30, 6, utf8_decode($row['Clv_editorial']), 1, 0, 'C');
    $pdf->Cell(160, 6, utf8_decode(substr($row['Nombre_editorial'], 0, 160)), 1, 1, 'L');
}

// --- Tabla de Disciplinas ---
// Posición inicial de la tabla de disciplinas
$posX_disciplinas = 10;
$posY_disciplinas = $pdf->GetY() + 10;

// Consulta para obtener disciplinas
$query_disciplinas = "
    SELECT Clv_disciplina, Descripcion
    FROM disciplina
";

$result_disciplinas = mysqli_query($conexion, $query_disciplinas);

// Verificar si hubo errores en la consulta
if (!$result_disciplinas) {
    die("Error al ejecutar la consulta de disciplinas: " . mysqli_error($conexion));
}

// Mostrar tabla de disciplinas
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetXY($posX_disciplinas, $posY_disciplinas);
$pdf->Cell(30, 6, utf8_decode('Clave Disciplina'), 1, 0, 'C');
$pdf->Cell(160, 6, utf8_decode('Descripción Disciplina'), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
while ($row = mysqli_fetch_assoc($result_disciplinas)) {
    $pdf->SetX($posX_disciplinas);
    $pdf->Cell(30, 6, utf8_decode($row['Clv_disciplina']), 1, 0, 'C');
    $pdf->Cell(160, 6, utf8_decode(substr($row['Descripcion'], 0, 160)), 1, 1, 'L');
}

// Cerrar conexión
mysqli_close($conexion);

// Definir el nombre del archivo PDF
$nombre_archivo = 'reporte_prestamos_series_generos_editoriales_disciplinas.pdf';

// Mostrar el PDF en el navegador
$pdf->Output('I', $nombre_archivo);
?>
