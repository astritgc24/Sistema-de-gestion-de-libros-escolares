<?php
// Incluir archivo de conexión a la base de datos
include("conexion/conectar-mysql.php");

// Verificar si se recibieron datos por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener datos del formulario y escaparlos para evitar inyección SQL
    $matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $apellido1 = mysqli_real_escape_string($conexion, $_POST['apellido1']);
    $apellido2 = mysqli_real_escape_string($conexion, $_POST['apellido2']);
    $grado = mysqli_real_escape_string($conexion, $_POST['grado']);
    $grupo = mysqli_real_escape_string($conexion, $_POST['grupo']);

    // Mostrar datos recibidos (depuración)
    echo "Datos recibidos del formulario:<br>";
    echo "Matrícula: " . $matricula . "<br>";
    echo "Nombre: " . $nombre . "<br>";
    echo "Apellido Paterno: " . $apellido1 . "<br>";
    echo "Apellido Materno: " . $apellido2 . "<br>";
    echo "Grado: " . $grado . "<br>";
    echo "Grupo: " . $grupo . "<br>";

    // Llamar al procedimiento almacenado para registrar alumno
    $query = "CALL RegistrarAlumno('$matricula', '$nombre', '$apellido1', '$apellido2', '$grado', '$grupo')";
    echo "Query ejecutada: " . $query . "<br>"; // Mostrar la consulta SQL generada (depuración)

    $resultado = mysqli_query($conexion, $query);

    if ($resultado) {
        $mensaje = "Alumno registrado correctamente.";
        echo "<script>
                alert('$mensaje');
                window.location.href = 'mostrarAlumnos.php'; // Redireccionar a la página de listado de alumnos
              </script>";
        exit(); // Salir del script después de la redirección
    } else {
        $error = "Error al registrar el alumno: " . mysqli_error($conexion);
        echo "<script>
                alert('$error');
                window.history.back(); // Regresar a la página anterior en caso de error
              </script>";
        exit(); // Salir del script después de mostrar el error
    }
} else {
    // Si no se recibieron datos por POST, redireccionar a página de error o manejar de acuerdo a la lógica de tu aplicación
    header("Location: error.php");
    exit();
}

// Cerrar la conexión
mysqli_close($conexion);
?>
