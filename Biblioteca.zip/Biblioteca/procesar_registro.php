<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca_escolar";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recibir datos del formulario
$correo = $_POST['correo'];
$nombre = $_POST['nombre'];
$contraseña = password_hash($_POST['contraseña'], PASSWORD_BCRYPT);

// Validar formato de correo
if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    $mensaje = "Formato de correo inválido.";
    header("Location: registro.php?mensaje=" . urlencode($mensaje));
    exit();
}

// Preparar y ejecutar la inserción
$sql = "INSERT INTO usuarios (correo, nombre, contraseña) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $correo, $nombre, $contraseña);

if ($stmt->execute()) {
    $mensaje = "Registro exitoso.";
    header("Location: registro.php?mensaje=" . urlencode($mensaje));
} else {
    $mensaje = "Error: " . $conn->error;
    header("Location: registro.php?mensaje=" . urlencode($mensaje));
}

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
