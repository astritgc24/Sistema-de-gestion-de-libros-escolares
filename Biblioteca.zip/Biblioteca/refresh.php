
<?php
// refresh.php

// Redirigir a la página de origen
header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>
