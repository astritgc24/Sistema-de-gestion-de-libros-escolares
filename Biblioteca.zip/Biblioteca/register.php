<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "biblioteca_escolar";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$correo = $conn->real_escape_string($_POST['email']);
$nombre = $conn->real_escape_string($_POST['nombre']);
$contraseña = $_POST['password'];
$clave = $_POST['clave'];

// Validar la clave para determinar el rol
if ($clave === 'orientadorTecnico2024') {
    $rol = 'orientador';
} elseif ($clave === 'profesor2024') {
    $rol = 'profesor';
} else {
    echo 'Clave incorrecta';
    exit;
}

// Insertar el usuario en la base de datos
$sql = "INSERT INTO usuarios (correo, nombre, contraseña, rol) VALUES ('$correo', '$nombre', '$contraseña', '$rol')";

if ($conn->query($sql) === TRUE) {
    // Guardar el rol en una variable de sesión
    $_SESSION['rol'] = $rol;
    echo 'Usuario registrado correctamente';
} else {
    echo 'Error al registrar usuario: ' . $conn->error;
}

$conn->close();
?>
