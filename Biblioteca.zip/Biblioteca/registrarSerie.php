<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Series</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
        }
        h2 {
            margin-bottom: 20px;
            font-weight: bold;
            color: #000; /* Color negro para el título */
            display: flex;
            align-items: center;
        }
        h2 img {
            margin-right: 15px;
            width: 60px; /* Tamaño aumentado del icono */
            height: auto;
        }
        .btn-custom {
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px; /* Espacio entre botones */
            margin-right: 10px; /* Espacio entre botones */
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .back-button {
            margin-top: 10px;
            padding: 15px 20px; /* Tamaño fijo de los botones */
        }
        .alert {
            margin-top: 10px;
            font-size: 16px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>

<div class="container">
    <h2><img src="images/ejemplar.png" alt="icono"> SERIES</h2>

    <?php
    // Procesar el formulario y mostrar mensajes de éxito o error
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Configuración de la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "biblioteca_escolar";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Nombre de la serie
        $nombre = $_POST['nombre'];

        // Imagen de la serie
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["imagen"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Verificar si el archivo es una imagen real
        $check = getimagesize($_FILES["imagen"]["tmp_name"]);
        if ($check !== false) {
            
            $uploadOk = 1;
        } else {
            echo "<div class='alert alert-danger'>El archivo no es una imagen.</div>";
            $uploadOk = 0;
        }

        // Verificar si el archivo ya existe
        if (file_exists($target_file)) {
            echo "<div class='alert alert-danger'>Lo siento, el archivo ya existe.</div>";
            $uploadOk = 0;
        }

        // Verificar el tamaño del archivo
        if ($_FILES["imagen"]["size"] > 500000) {
            echo "<div class='alert alert-danger'>Lo siento, tu archivo es demasiado grande.</div>";
            $uploadOk = 0;
        }

        // Permitir ciertos formatos de archivo
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "<div class='alert alert-danger'>Lo siento, solo se permiten archivos JPG, JPEG, PNG y GIF.</div>";
            $uploadOk = 0;
        }

        // Verificar si $uploadOk es 0 debido a un error
        if ($uploadOk == 0) {
            echo "<div class='alert alert-danger'>Lo siento, tu archivo no fue subido.</div>";
        // Si todo está bien, intentar subir el archivo
        } else {
            if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
                // Insertar datos en la base de datos
                $sql = "INSERT INTO serie (Nombre_serie, imagen) VALUES ('$nombre', '$target_file')";
                if ($conn->query($sql) === TRUE) {
                    echo "<div class='alert alert-success'>Serie registrada exitosamente.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error al registrar la serie: " . $conn->error . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Lo siento, hubo un error al subir tu archivo.</div>";
            }
        }

        // Cerrar conexión
        $conn->close();
    }
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nombre">Nombre de la Serie:</label>
            <input type="text" class="form-control" id="nombre" name="nombre" required>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen de la Serie:</label>
            <input type="file" class="form-control-file" id="imagen" name="imagen" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-custom">Registrar Serie</button>
        <a href="series.php" class="btn btn-secondary back-button">Volver a Series</a>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

