<?php
// Incluir archivo de conexión a la base de datos
include 'conexion/conectar-mysql.php';

// Verificar si se recibió el parámetro del folio de préstamo y folio de ejemplar
if (!isset($_GET['folio_prestamo']) || !isset($_GET['folio_ejemplar'])) {
    die("Error: No se proporcionaron los datos del préstamo.");
}

// Obtener los datos desde el parámetro GET
$folioPrestamo = $_GET['folio_prestamo'];
$folioEjemplar = $_GET['folio_ejemplar'];

// Consulta para obtener los detalles del préstamo
$query = "SELECT
            p.Folio_prestamo AS Clave,
            e.Folio AS Folio,
            e.ISBN,
            l.Titulo AS Titulo,
            a.Matricula,
            a.Nombre,
            a.Ap1 AS ApellidoPaterno,
            a.Ap2 AS ApellidoMaterno,
            a.Grado,
            a.Grupo,
            e.Estado
          FROM
            prestamo p
            INNER JOIN ejemplar e ON p.Folio_ejemplar = e.Folio
            INNER JOIN libro l ON e.ISBN = l.ISBN
            INNER JOIN alumno a ON p.Matricula = a.Matricula
          WHERE
            p.Folio_prestamo = ? AND e.Folio = ?";

// Preparar la consulta
$stmt = mysqli_prepare($conexion, $query);

// Verificar si hubo un error en la preparación de la consulta
if ($stmt === false) {
    die("Error al preparar la consulta: " . mysqli_error($conexion));
}

// Vincular los parámetros
mysqli_stmt_bind_param($stmt, "ii", $folioPrestamo, $folioEjemplar);

// Ejecutar la consulta
mysqli_stmt_execute($stmt);

// Obtener el resultado
$resultado = mysqli_stmt_get_result($stmt);

// Verificar si se encontró el préstamo
if (mysqli_num_rows($resultado) === 0) {
    die("No se encontró el préstamo con los datos proporcionados.");
}

// Obtener los detalles del préstamo
$prestamo = mysqli_fetch_assoc($resultado);

// Cerrar la consulta
mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Fecha de Entrega</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Estilos personalizados -->
    <style>
        .card {
            margin-top: 20px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .card-title {
            color: #007bff;
        }
        .card-text strong {
            width: 150px;
            display: inline-block;
            font-weight: bold;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4 text-center">Registrar Fecha de Entrega</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Detalles del Préstamo <i class="fas fa-info-circle"></i></h5>
                <p class="card-text">
                    <strong>Folio Préstamo:</strong> <?php echo $prestamo['Clave']; ?><br>
                    <strong>Folio Ejemplar:</strong> <?php echo $prestamo['Folio']; ?><br>
                    <strong>ISBN:</strong> <?php echo $prestamo['ISBN']; ?><br>
                    <strong>Título:</strong> <?php echo $prestamo['Titulo']; ?><br>
                    <strong>Matrícula:</strong> <?php echo $prestamo['Matricula']; ?><br>
                    <strong>Nombre:</strong> <?php echo $prestamo['Nombre']; ?><br>
                    <strong>Apellido Paterno:</strong> <?php echo $prestamo['ApellidoPaterno']; ?><br>
                    <strong>Apellido Materno:</strong> <?php echo $prestamo['ApellidoMaterno']; ?><br>
                    <strong>Grado:</strong> <?php echo $prestamo['Grado']; ?><br>
                    <strong>Grupo:</strong> <?php echo $prestamo['Grupo']; ?><br>
                    <strong>Estado:</strong> <?php echo $prestamo['Estado']; ?><br>
                </p>

                <form action="guardar_fecha_entrega.php" method="post">
                    <input type="hidden" name="folio_prestamo" value="<?php echo $folioPrestamo; ?>">
                    <input type="hidden" name="folio_ejemplar" value="<?php echo $folioEjemplar; ?>">
                    <div class="form-group">
                        <label for="fecha_entrega">Fecha de Entrega <i class="fas fa-calendar-alt"></i>:</label>
                        <input type="date" class="form-control" id="fecha_entrega" name="fecha_entrega" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Guardar Fecha de Entrega</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap y otros scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>
