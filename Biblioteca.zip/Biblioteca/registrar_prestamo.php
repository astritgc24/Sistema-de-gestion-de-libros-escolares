<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Iniciar sesión al principio del script
session_start();

// Incluir el archivo de conexión
include("conexion/conectar-mysql.php");

// Verificar la conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Verificar si la variable de sesión 'nombre' está establecida
if (isset($_SESSION['nombre'])) {
    // Obtener el nombre de usuario de la sesión
    $nombre = $_SESSION['nombre'];

    // Consulta para obtener el rol del usuario basado en el nombre
    $query = "SELECT rol FROM usuarios WHERE nombre = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param('s', $nombre);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        // Verificar si se encontró un registro
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $rol = $row['rol'];

            // Verificar si el rol es 'orientador'
            if ($rol === 'orientador') {
                // Inicializar variables
                $folio = '';
                $isbn = '';
                $titulo = '';

                // Obtener datos de ejemplar (supongamos que los recibes por GET)
                if (isset($_GET['folio'])) {
                    $folio = htmlspecialchars($_GET['folio']);
                }
                if (isset($_GET['isbn'])) {
                    $isbn = htmlspecialchars($_GET['isbn']);
                }
                if (isset($_GET['titulo'])) {
                    $titulo = htmlspecialchars($_GET['titulo']);
                }

                // Verificar si se recibieron datos del formulario por POST
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    // Recibir datos del formulario
                    $folio = $_POST['folio'];
                    $isbn = $_POST['isbn'];
                    $titulo = $_POST['titulo'];
                    $matricula = $_POST['matricula'];
                    $fecha_prestamo = $_POST['fecha_prestamo'];

                    // Validar que la matrícula no esté vacía
                    if (empty($matricula)) {
                        die("Error: La matrícula del alumno es requerida.");
                    }

                    // Llamar al procedimiento almacenado RegistrarPrestamo
                    $query = "CALL RegistrarPrestamo(?, ?, ?, '')"; // Suponemos que fecha_entrega puede ser vacía o nula
                    $stmt = $conexion->prepare($query);
                    $stmt->bind_param('sss', $folio, $matricula, $fecha_prestamo);
                    
                    if ($stmt->execute()) {
                        // Procesar todos los resultados devueltos por el procedimiento almacenado
                        do {
                            if ($result = $stmt->get_result()) {
                                $result->free();
                            }
                        } while ($stmt->more_results() && $stmt->next_result());

                        // Establecer mensaje de éxito utilizando variables de sesión
                        $_SESSION['mensaje_exito'] = "Préstamo registrado exitosamente.";

                        // Redirigir a consultar_prestamos.php después de 2 segundos
                        header("refresh:2; url=consultar_prestamos.php");
                        exit();
                    } else {
                        // Mostrar el error de MySQL
                        echo "Error al registrar el préstamo: " . $stmt->error;
                    }

                    $stmt->close();
                }

                // Consulta para obtener matrículas de los alumnos
                $query_alumnos = "SELECT Matricula, CONCAT(Matricula, ' - ', Nombre, ' ', Ap1) AS NombreCompleto FROM alumno";
                $result_alumnos = mysqli_query($conexion, $query_alumnos);
                if (!$result_alumnos) {
                    die("Error al consultar alumnos: " . mysqli_error($conexion));
                }
                ?>

                <!DOCTYPE html>
                <html lang="es">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Registrar Préstamo</title>
                    <!-- Bootstrap CSS -->
                    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
                    <!-- Bootstrap Icons CSS -->
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
                    <!-- Estilos personalizados -->
                    <style>
                        .logo {
                            position: absolute;
                            top: 10px;
                            right: 10px;
                            width: 100px; /* Ajusta el tamaño según sea necesario */
                            height: auto;
                        }
                    </style>
                </head>
                <body>
                    <!-- Logo -->
                    <img src="images/log.png" alt="Logo" class="logo">

                    <div class="container mt-5">
                        <h1 class="text-center">Registrar Préstamo <i class="bi bi-journal-plus"></i></h1>

                        <!-- Mostrar mensaje de éxito si existe -->
                        <?php
                        if (isset($_SESSION['mensaje_exito'])) {
                            echo '<div class="alert alert-success" role="alert">' . $_SESSION['mensaje_exito'] . '</div>';
                            unset($_SESSION['mensaje_exito']); // Limpiar mensaje de sesión
                        }
                        ?>

                        <form action="registrar_prestamo.php" method="POST">
                            <!-- Campos del ejemplar seleccionado -->
                            <div class="form-group">
                                <label for="folio">Folio del Ejemplar</label>
                                <input type="hidden" id="clave_prestamo" name="clave_prestamo">
                                <input type="text" class="form-control" id="folio" name="folio" value="<?php echo $folio; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="isbn">ISBN</label>
                                <input type="text" class="form-control" id="isbn" name="isbn" value="<?php echo $isbn; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="titulo">Título</label>
                                <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo $titulo; ?>" readonly>
                            </div>

                            <!-- Campos del préstamo -->
                            <div class="form-group">
                                <label for="matricula">Matrícula del Alumno <i class="bi bi-person-badge"></i></label>
                                <select class="form-control" id="matricula" name="matricula" required>
                                    <option value="">Seleccionar Matrícula</option>
                                    <?php
                                    while ($fila = mysqli_fetch_assoc($result_alumnos)) {
                                        echo "<option value='" . $fila['Matricula'] . "'>" . $fila['NombreCompleto'] . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="fecha_prestamo">Fecha de Préstamo <i class="bi bi-calendar-plus"></i></label>
                                <input type="date" class="form-control" id="fecha_prestamo" name="fecha_prestamo" required>
                            </div>
                           
                            <button type="submit" class="btn btn-primary">Registrar Préstamo <i class="bi bi-check-circle"></i></button>
                        </form>
                    </div>

                    <!-- Bootstrap y otros scripts -->
                    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
                    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
                </body>
                </html>

                <?php
                // Liberar resultados de la consulta de alumnos
                mysqli_free_result($result_alumnos);

            } else {
                // Mostrar un mensaje de error para otros roles
                echo "Usted no tiene los suficientes permisos para registrar préstamos.";
            }
        } else {
            // Mostrar un mensaje de error si no se encontró el usuario
            echo "Usuario no encontrado.";
        }
        // Liberar resultados de la consulta de roles
        $result->free();
    } else {
        // Mostrar un mensaje de error si la consulta falló
        echo "Error al consultar la base de datos.";
    }
} else {
    // La variable de sesión 'nombre' no está establecida, mostrar un mensaje de error
    echo "No se ha iniciado sesión.";
}

// Cerrar conexión
mysqli_close($conexion);
?>
