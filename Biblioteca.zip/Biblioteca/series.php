<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Series</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        h1 {
            margin-bottom: 30px;
        }
        .table img {
            display: block;
            margin: 0 auto;
            width: 100px; /* Ajusta el tamaño de las imágenes */
        }
        .btn-editar, .btn-eliminar {
            font-size: 14px;
            padding: 6px 12px;
        }
        .btn-editar {
            background-color: #007bff;
            color: #fff;
            border: 1px solid #007bff;
        }
        .btn-editar:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .btn-eliminar {
            background-color: #dc3545;
            color: #fff;
            border: 1px solid #dc3545;
        }
        .btn-eliminar:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row header-container align-items-center">
            <div class="col-auto">
                <h5 class="text-uppercase">SERIES</h5>
            </div>
            <div class="col nav-links justify-content-center">
                <a href="registrarSerie.php">
                    <img src="imagenes/registrar.png" alt="Registrar" style="width: 30px; height: auto;">
                    <span>Registrar</span>
                </a>
            </div>
            <div class="col-auto ml-auto nav-icons">
                <a href="index.html" class="btn-exit-system">
                    <img src="images/log.png" alt="Cerrar sesión" style="width: 100px; height: auto;">
                </a>
            </div>
        </div>
        
        <h1 class="text-center">Tabla de Series</h1>
        
        <div class="text-right mb-3">
            <a href="inicio.php" class="btn btn-primary">Ir a Inicio</a>
        </div>

        <table class="table table-bordered table-hover">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Nombre de la Serie</th>
                    <th scope="col">Imagen</th>
                    <th scope="col">Acciones</th> <!-- Nuevo encabezado para acciones -->
                </tr>
            </thead>
            <tbody>
                <?php
                // Incluir archivo de conexión
                include("conexion/conectar-mysql.php");

                // Verificar si la conexión está establecida correctamente
                if ($conexion) {
                    // Consultar datos de la tabla serie
                    $sql = "SELECT clv_serie, Nombre_serie, imagen FROM serie";
                    $result = $conexion->query($sql);

                    if ($result->num_rows > 0) {
                        // Salida de datos de cada fila
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["Nombre_serie"]) . "</td>";
                            echo "<td><img src='" . htmlspecialchars($row["imagen"]) . "' alt='" . htmlspecialchars($row["Nombre_serie"]) . "' class='img-fluid'></td>";
                            echo "<td>";
                            echo "<a href='editar_serie.php?clv_serie=" . urlencode($row["clv_serie"]) . "' class='btn btn-editar'>Editar</a>";
                            echo "<a href='eliminar_serie.php?clv_serie=" . urlencode($row["clv_serie"]) . "' class='btn btn-eliminar ml-1'>Eliminar</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No se encontraron series</td></tr>";
                    }

                    // Liberar el conjunto de resultados
                    $result->free();

                    // Cerrar conexión
                    $conexion->close();
                } else {
                    echo "<tr><td colspan='3'>Error al conectar con la base de datos</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
