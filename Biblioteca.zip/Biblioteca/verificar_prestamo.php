<?php
// Incluir archivo de conexión
include("conexion/conectar-mysql.php");

if (isset($_POST['folio'])) {
    $folio = $_POST['folio'];

    // Consulta para verificar si el ejemplar está en préstamo
    $sql = "SELECT * FROM prestamo WHERE Folio_ejemplar = ? AND Fecha_Entrega IS NULL";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $folio);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo 'en_prestamo';
    } else {
        echo 'disponible';
    }

    $stmt->close();
    $conexion->close();
}
?>
